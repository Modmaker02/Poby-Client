# Poby Client v1.6 - Frost (Fabric 1.21.11)

Client-side Fabric mod. Build: `./gradlew build` -> `build/libs/poby-client-1.0.0.jar` -> drop into `mods/` with Fabric API.

* Right Shift: Poby Menu (modules, preferences, keybinds)
* Right Ctrl: HUD Editor (drag enabled HUD elements)
* G: Toggle Sprint, B: Full Bright  (all rebindable in Menu > Keybinds)
* Config: `config/poby-client.json`

If the Gradle wrapper is missing, copy `gradlew`, `gradlew.bat` and the `gradle/` folder from any of your other Fabric mod projects.
