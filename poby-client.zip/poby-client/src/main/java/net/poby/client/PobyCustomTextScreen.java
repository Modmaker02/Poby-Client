package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class PobyCustomTextScreen extends PobyScreen {
    static final int PW = 560, PH = 330, ROWS = 6, STRIDE = 36;
    static final String[] STYLES = {"Gradient", "White", "Solid"};
    static final String[] SIZES = {"Small", "Normal", "Large", "Huge"};
    static final int[] SWATCH = {0xFFFFFF, 0x2D8CFF, 0x00D4FF, 0x2EE59D, 0xFFD93D, 0xFF9F43, 0xFF5C5C, 0xFF7BC8};

    private final Screen parent;
    private int px, py, first, sel;
    private TextFieldWidget field;

    public PobyCustomTextScreen(Screen parent) {
        super(Text.literal("Custom Texts"));
        this.parent = parent;
    }

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
    }

    private Config.TextItem cur() {
        var l = Config.I.texts;
        return sel >= 0 && sel < l.size() ? l.get(sel) : null;
    }

    private void rebuild() { clearChildren(); init(); }

    @Override
    protected void init() {
        layout();
        field = null;
        Config.TextItem it = cur();
        if (it != null) {
            field = new TextFieldWidget(textRenderer, (int) ((px + 248) * s), (int) ((py + 76) * s),
                (int) (280 * s), Math.max(14, (int) (16 * s)), Text.literal("Text"));
            field.setMaxLength(60);
            field.setText(it.text);
            field.setChangedListener(v -> { Config.TextItem c = cur(); if (c != null) c.text = v; });
            addDrawableChild(field);
        }
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }

    @Override
    protected void onScroll(int d) {
        first = Math.max(0, Math.min(first + d, Math.max(0, Config.I.texts.size() - ROWS)));
    }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.window(g, px, py, PW, PH);
    }

    private static String fit(String s, int maxW) {
        if (s == null || s.isEmpty()) return "(empty)";
        if (Gfx.width(s) <= maxW) return s;
        while (s.length() > 1 && Gfx.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private boolean seg(DrawContext g, String label, int x, int y, int w, int h, boolean on) {
        boolean hv = hover(x, y, w, h);
        if (on) Gfx.rrectH(g, x, y, w, h, h / 2, 1f);
        else Gfx.rrect(g, x, y, w, h, h / 2, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
        centered(g, label, x + w / 2, y + (h - 8) / 2, 1f, 1f, on ? Gfx.BASE : Gfx.WHITE);
        return pressed && hv;
    }

    private boolean row(DrawContext g, String label, int x, int y, int w, boolean on, String key) {
        boolean hv = hover(x, y, w, 24);
        Gfx.rrect(g, x, y, w, 24, 8, Gfx.argb(0xFFFFFF, hv ? 0.12f : 0.07f));
        Gfx.text(g, label, x + 10, y + 8, 1f, 1f, Gfx.WHITE);
        toggle(g, x + w - 40, y + 5, on, key);
        return pressed && hv;
    }

    @Override
    protected void paintFront(DrawContext g) {
        var texts = Config.I.texts;
        if (iconButton(g, "<", px + 20, py + 14, 26)) act(this::close);
        Gfx.text(g, "Custom Texts", px + 56, py + 19, 1.5f, 1f, -1);

        Hud.Mod master = Hud.get("customtext");
        Gfx.text(g, "Module", px + PW - 20 - 110 - 8 - 28 - 38, py + 22, 1f, 0.9f, Gfx.MUTED);
        int mx0 = px + PW - 20 - 110 - 8 - 28, my0 = py + 20;
        toggle(g, mx0, my0, master.on(), "master");
        if (pressed && hover(mx0 - 4, my0 - 4, 36, 22)) master.set(!master.on());
        if (button(g, "+  Add Text", px + PW - 20 - 110, py + 14, 110, 26, true)) {
            act(() -> {
                Config.TextItem n = new Config.TextItem();
                Config.I.texts.add(n);
                sel = Config.I.texts.size() - 1;
                first = Math.max(0, Config.I.texts.size() - ROWS);
                Hud.syncCustom();
                Config.save();
                rebuild();
            });
        }

        // ---- list
        int lx = px + 20, lw = 200;
        first = Math.max(0, Math.min(first, Math.max(0, texts.size() - ROWS)));
        for (int k = 0; k < ROWS; k++) {
            int i = first + k;
            if (i >= texts.size()) break;
            Config.TextItem it = texts.get(i);
            int y = py + 54 + k * STRIDE;
            boolean hv = hover(lx, y, lw, 32), isSel = i == sel;
            if (isSel) {
                Gfx.rrectH(g, lx - 1, y - 1, lw + 2, 34, 11, 0.9f);
                Gfx.rrect(g, lx, y, lw, 32, 10, Gfx.argb(Gfx.BASE, 0.95f));
            } else {
                Gfx.glass(g, lx, y, lw, 32, 10, 0.35f, hv ? 0.05f : 0f);
            }
            Gfx.text(g, fit(it.text, lw - 88), lx + 10, y + 12, 1f, 1f, it.enabled ? Gfx.WHITE : Gfx.MUTED);
            boolean onDel = hover(lx + lw - 66, y + 7, 18, 18), onTog = hover(lx + lw - 42, y + 4, 38, 24);
            if (iconButton(g, "x", lx + lw - 66, y + 7, 18)) {
                final int idx = i;
                act(() -> {
                    Config.I.pos.remove("ct:" + Config.I.texts.get(idx).id);
                    Config.I.texts.remove(idx);
                    sel = Math.max(0, Math.min(sel, Config.I.texts.size() - 1));
                    if (idx < sel) sel--;
                    Hud.syncCustom();
                    Config.save();
                    rebuild();
                });
            }
            toggle(g, lx + lw - 38, y + 9, it.enabled, "e" + it.id);
            if (pressed && onTog) it.enabled = !it.enabled;
            else if (pressed && hv && !onDel && i != sel) {
                final int idx = i;
                act(() -> { sel = idx; rebuild(); });
            }
        }
        if (texts.isEmpty()) {
            centered(g, "No texts yet", lx + lw / 2, py + 120, 1f, 1f, Gfx.WHITE);
        }
        if (texts.size() > ROWS) {
            Gfx.text(g, (first + 1) + "-" + Math.min(texts.size(), first + ROWS) + " of " + texts.size() + "  (scroll)", lx, py + 54 + ROWS * STRIDE + 2, 0.9f, 1f, Gfx.MUTED);
        }

        // ---- settings panel
        int rx = px + 236, ry = py + 54, rw = PW - 256, rh = 216;
        Gfx.glass(g, rx, ry, rw, rh, 12, 0.35f, 0f);
        Config.TextItem it = cur();
        if (it == null) {
            centered(g, "Add a text with the + button", rx + rw / 2, ry + 100, 1f, 1f, Gfx.WHITE);
            return;
        }
        Gfx.text(g, "Text", rx + 12, ry + 10, 0.9f, 1f, Gfx.MUTED);
        Gfx.text(g, "Color style", rx + 12, ry + 46, 0.9f, 1f, Gfx.MUTED);
        int sw = (rw - 24 - 12) / 3;
        for (int i = 0; i < 3; i++) {
            if (seg(g, STYLES[i], rx + 12 + i * (sw + 6), ry + 58, sw, 20, it.style == i)) it.style = i;
        }
        if (it.style == 2) {
            for (int i = 0; i < SWATCH.length; i++) {
                int x = rx + 14 + i * 28, y = ry + 86;
                boolean hv = hover(x - 2, y - 2, 22, 22);
                if ((it.color & 0xFFFFFF) == SWATCH[i]) Gfx.rrect(g, x - 3, y - 3, 24, 24, 12, 0xFFFFFFFF);
                else if (hv) Gfx.rrect(g, x - 2, y - 2, 22, 22, 11, 0x99FFFFFF);
                Gfx.rrect(g, x, y, 18, 18, 9, 0xFF000000 | SWATCH[i]);
                if (pressed && hv) it.color = SWATCH[i];
            }
        }
        Gfx.text(g, "Size", rx + 12, ry + 112, 0.9f, 1f, Gfx.MUTED);
        int sz = (rw - 24 - 18) / 4;
        for (int i = 0; i < 4; i++) {
            if (seg(g, SIZES[i], rx + 12 + i * (sz + 6), ry + 124, sz, 20, it.size == i)) it.size = i;
        }
        if (row(g, "Background", rx + 12, ry + 154, rw - 24, it.bg, "bg" + it.id)) it.bg = !it.bg;
        if (row(g, "Underline", rx + 12, ry + 182, rw - 24, it.underline, "ul" + it.id)) it.underline = !it.underline;
    }
}
