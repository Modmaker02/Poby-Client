package net.poby.client;

import org.lwjgl.glfw.GLFW;

/** Raw GLFW key helpers (so Poby keybinds are fully custom and work in our own screens). */
public final class Keys {
    private Keys() {}

    public static boolean valid(int k) {
        return k == 32 || k == 39 || (k >= 44 && k <= 57) || k == 59 || k == 61 || (k >= 65 && k <= 93)
            || k == 96 || k == 161 || k == 162 || (k >= 256 && k <= 269) || (k >= 280 && k <= 284)
            || (k >= 290 && k <= 314) || (k >= 320 && k <= 336) || (k >= 340 && k <= 348);
    }

    public static boolean down(long win, int k) {
        return k > 0 && valid(k) && GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
    }

    public static String name(int k) {
        if (k <= 0) return "NONE";
        switch (k) {
            case 340: return "Left Shift";
            case 344: return "Right Shift";
            case 341: return "Left Ctrl";
            case 345: return "Right Ctrl";
            case 342: return "Left Alt";
            case 346: return "Right Alt";
            case 32: return "Space";
            case 258: return "Tab";
            case 257: return "Enter";
            case 259: return "Backspace";
            case 261: return "Delete";
            case 260: return "Insert";
            case 268: return "Home";
            case 269: return "End";
            case 266: return "Page Up";
            case 267: return "Page Down";
            case 262: return "Arrow Right";
            case 263: return "Arrow Left";
            case 264: return "Arrow Down";
            case 265: return "Arrow Up";
            case 280: return "Caps Lock";
            default: break;
        }
        if (k >= 290 && k <= 314) return "F" + (k - 289);
        if (k >= 320 && k <= 329) return "Numpad " + (k - 320);
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "Key " + k;
    }
}
