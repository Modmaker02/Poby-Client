package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class PobyLoadingPreviewScreen extends PobyScreen {
    private final Screen parent;
    private final long start = System.currentTimeMillis();

    public PobyLoadingPreviewScreen(Screen parent) {
        super(Text.literal("Loading preview"));
        this.parent = parent;
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    protected void paintBack(DrawContext g) { LoadingUi.draw(g, dw, dh, Config.I.loadSub); }

    @Override
    protected void paintFront(DrawContext g) {
        Gfx.text(g, "Preview  -  click or press ESC to close", 8, 8, 1f, 0.8f, Gfx.WHITE);
        if (pressed && System.currentTimeMillis() - start > 300) act(this::close);
    }
}
