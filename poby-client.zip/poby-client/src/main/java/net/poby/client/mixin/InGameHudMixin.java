package net.poby.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.poby.client.StatsMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla scoreboard sidebar while the Sidebar Stats module is on. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
        at = @At("HEAD"), cancellable = true, require = 0)
    private void poby$hideSidebar(DrawContext ctx, ScoreboardObjective objective, CallbackInfo ci) {
        if (StatsMod.hiding()) ci.cancel();
    }

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
        at = @At("HEAD"), cancellable = true, require = 0)
    private void poby$hideSidebar2(DrawContext ctx, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (StatsMod.hiding()) ci.cancel();
    }
}
