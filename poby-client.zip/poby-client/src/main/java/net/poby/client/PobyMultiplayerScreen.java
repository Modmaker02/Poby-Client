package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;

public class PobyMultiplayerScreen extends PobyListScreen {
    final ServerList list;

    public PobyMultiplayerScreen(Screen parent) {
        super("Multiplayer", parent);
        list = new ServerList(MinecraftClient.getInstance());
        list.loadFile();
    }

    @Override
    protected int count() { return list.size(); }

    @Override
    protected String countLabel() { return list.size() + " servers"; }

    @Override
    protected String emptyText() { return "No servers saved - add one below!"; }

    @Override
    protected void drawRow(DrawContext g, int i, int x, int y, int w, int h, boolean hv) {
        ServerInfo si = list.get(i);
        ServerIcons.Info in = ServerIcons.info(si);
        if (!ServerIcons.drawPixels(g, in.px, x + 8, y + 6)) rowIcon(g, si.name, x, y);
        Gfx.text(g, si.name, x + 48, y + 9, 1f, 1f, Gfx.WHITE);
        String sub = si.address;
        if (in.online >= 0) sub += "   -   " + in.online + "/" + in.max + " players";
        if (in.ms >= 0) sub += "   -   " + in.ms + " ms";
        else if (in.done) sub += "   -   offline";
        Gfx.text(g, sub, x + 48, y + 24, 0.85f, 1f, Gfx.MUTED);
        if (button(g, "Join", x + w - 66, y + 11, 56, 22, true)) {
            act(() -> ConnectScreen.connect(this, client, ServerAddress.parse(si.address), si, false, null));
        }
        if (iconButton(g, "x", x + w - 96, y + 11, 22)) {
            act(() -> { list.remove(si); list.saveFile(); });
        }
    }

    @Override
    protected void bottom(DrawContext g, int by) {
        if (button(g, "+  Add Server", px + 20, by, 150, 26, true)) {
            act(() -> client.setScreen(new PobyAddServerScreen(this, list)));
        }
        if (button(g, "Refresh", px + 180, by, 90, 26, false)) {
            act(() -> { for (int k = 0; k < list.size(); k++) ServerIcons.forget(list.get(k).address); });
        }
        if (button(g, "Back", px + PW - 20 - 90, by, 90, 26, false)) act(this::close);
    }
}
