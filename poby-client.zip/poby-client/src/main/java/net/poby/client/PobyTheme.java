package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.TexturedButtonWidget;
import net.minecraft.text.Text;

/** Applies the Frost look to vanilla screens (loading, create world, joining, options...). */
public final class PobyTheme {
    private PobyTheme() {}

    private static boolean menusAllowed() {
        if (!Config.I.themeMenus) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.world == null || mc.isInSingleplayer() || Config.I.themeOnServers;
    }

    public static boolean screenActive(Screen s) {
        return menusAllowed() && !(s instanceof PobyScreen) && !(s instanceof HandledScreen<?>) && !(s instanceof ChatScreen);
    }

    /** @return true if the vanilla background was replaced */
    public static boolean background(DrawContext g) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
            if (mc.world == null) Gfx.backdrop(g, w, h);
            else g.fill(0, 0, w, h, 0xB0050A14);
            return true;
        } catch (Throwable t) {
            Log.error("theme.background", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    public static boolean sliderAllowed() { return menusAllowed(); }

    public static boolean buttonStyled(ClickableWidget w) {
        return menusAllowed() && (w instanceof ButtonWidget || w instanceof CyclingButtonWidget<?>)
            && !(w instanceof TexturedButtonWidget);
    }

    public static boolean button(DrawContext g, ClickableWidget w) {
        try {
            int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
            boolean hv = w.isHovered() || w.isFocused(), on = w.active;
            int acc = Gfx.accent();
            g.fill(x, y, x + bw, y + bh, Gfx.argb(hv && on ? Gfx.BTN_HI : Gfx.BTN, on ? 0.95f : 0.55f));
            Gfx.outline(g, x, y, bw, bh, hv && on ? Gfx.argb(acc, 1f) : Gfx.argb(Gfx.LINE, on ? 1f : 0.5f));
            if (hv && on) Gfx.outline(g, x + 1, y + 1, bw - 2, bh - 2, Gfx.argb(acc, 0.9f));
            label(g, w, x, y, bw, bh, on);
            return true;
        } catch (Throwable t) {
            Log.error("theme.button", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    public static boolean slider(DrawContext g, ClickableWidget w, double value) {
        try {
            int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
            boolean hv = w.isHovered() || w.isFocused(), on = w.active;
            int acc = Gfx.accent();
            double v = Math.max(0.0, Math.min(1.0, value));
            g.fill(x, y, x + bw, y + bh, Gfx.argb(Gfx.BTN, 0.95f));
            int fw = (int) ((bw - 4) * v);
            g.fill(x + 2, y + 2, x + 2 + fw, y + bh - 2, Gfx.argb(acc, 0.45f));
            int hx = x + (int) ((bw - 4) * v);
            g.fill(hx, y, hx + 4, y + bh, 0xFFFFFFFF);
            Gfx.outline(g, x, y, bw, bh, hv && on ? Gfx.argb(acc, 1f) : Gfx.argb(Gfx.LINE, 1f));
            label(g, w, x, y, bw, bh, on);
            return true;
        } catch (Throwable t) {
            Log.error("theme.slider", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    private static void label(DrawContext g, ClickableWidget w, int x, int y, int bw, int bh, boolean on) {
        TextRenderer f = MinecraftClient.getInstance().textRenderer;
        Text msg = w.getMessage();
        int tw = f.getWidth(msg);
        if (tw > bw - 8) {
            String str = msg.getString();
            while (str.length() > 1 && f.getWidth(Text.literal(str + "..")) > bw - 8) str = str.substring(0, str.length() - 1);
            msg = Text.literal(str + "..");
            tw = f.getWidth(msg);
        }
        g.drawText(f, msg, x + (bw - tw) / 2, y + (bh - 8) / 2, on ? 0xFFF2F8FF : 0xFF8FA3C0, false);
    }
}
