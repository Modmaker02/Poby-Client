package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.TexturedButtonWidget;
import net.minecraft.text.Text;

/** Applies the Frost look to vanilla screens (loading, create world, joining, options...). */
public final class PobyTheme {
    private PobyTheme() {}

    public static boolean screenActive(Screen s) {
        return Config.I.themeMenus && !(s instanceof PobyScreen) && !(s instanceof HandledScreen<?>) && !(s instanceof ChatScreen);
    }

    /** @return true if the vanilla background was replaced */
    public static boolean background(DrawContext g) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
            if (mc.world == null) Gfx.backdrop(g, w, h);
            else g.fill(0, 0, w, h, 0xB0050A14);
            return true;
        } catch (Throwable t) {
            Log.error("theme.background", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    public static boolean buttonStyled(ClickableWidget w) {
        return Config.I.themeMenus && (w instanceof ButtonWidget || w instanceof CyclingButtonWidget<?>)
            && !(w instanceof TexturedButtonWidget);
    }

    public static boolean button(DrawContext g, ClickableWidget w) {
        try {
            int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
            boolean hv = w.isHovered() || w.isFocused(), on = w.active;
            int r = Math.min(bh / 2, 10);
            Gfx.rrect(g, x, y, bw, bh, r, Gfx.argb(Gfx.BASE, on ? 0.65f : 0.45f));
            Gfx.rrect(g, x, y, bw, bh, r, Gfx.argb(0xFFFFFF, on ? (hv ? 0.16f : 0.08f) : 0.04f));
            Gfx.rrectStroke(g, x, y, bw, bh, r, hv && on ? Gfx.argb(Gfx.grad(0.5f), 1f) : Gfx.argb(0xFFFFFF, 0.22f));
            label(g, w, x, y, bw, bh, on);
            return true;
        } catch (Throwable t) {
            Log.error("theme.button", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    public static boolean slider(DrawContext g, ClickableWidget w, double value) {
        try {
            int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
            boolean hv = w.isHovered() || w.isFocused(), on = w.active;
            int r = Math.min(bh / 2, 10);
            double v = Math.max(0.0, Math.min(1.0, value));
            Gfx.rrect(g, x, y, bw, bh, r, Gfx.argb(Gfx.BASE, 0.65f));
            Gfx.rrect(g, x, y, bw, bh, r, Gfx.argb(0xFFFFFF, hv ? 0.14f : 0.07f));
            int fw = Math.max(bh, (int) (bw * v));
            Gfx.rrectH(g, x, y, Math.min(bw, fw), bh, r, 0.45f);
            Gfx.rrect(g, x + (int) ((bw - 6) * v), y, 6, bh, 3, 0xFFFFFFFF);
            Gfx.rrectStroke(g, x, y, bw, bh, r, hv && on ? Gfx.argb(Gfx.grad(0.5f), 1f) : Gfx.argb(0xFFFFFF, 0.22f));
            label(g, w, x, y, bw, bh, on);
            return true;
        } catch (Throwable t) {
            Log.error("theme.slider", t);
            Config.I.themeMenus = false;
            return false;
        }
    }

    private static void label(DrawContext g, ClickableWidget w, int x, int y, int bw, int bh, boolean on) {
        TextRenderer f = MinecraftClient.getInstance().textRenderer;
        Text msg = w.getMessage();
        int tw = f.getWidth(msg);
        g.drawText(f, msg, x + (bw - tw) / 2, y + (bh - 8) / 2, on ? 0xFFF2F8FF : 0xFF8FA3C0, false);
    }
}
