package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Sidebar Stats: the server's scoreboard sidebar (Money, Shards, Kills, Deaths, Playtime...) redrawn as a Frost panel
 * with your head and name. Turning the module on also hides the vanilla sidebar (see InGameHudMixin).
 */
public final class StatsMod extends Hud.Mod {
    private static final String[] KINDS = {"money", "shards", "kills", "deaths", "time"};
    private static final int[] COLORS = {0x2EE56B, 0xB05CFF, 0xFF4D4D, 0xFF9F43, 0xFFD93D};
    private static final String[][] ICONS = {
        {"....#....", "..#####..", ".#..#..#.", ".#..#....", "..#####..", "....#..#.", ".#..#..#.", "..#####..", "....#...."},
        {"....#....", "....#....", "...###...", "#########", ".#######.", "..#####..", "..##.##..", ".##...##.", ".#.....#."},
        {".......##", "......###", ".....###.", "#...###..", "##.###...", ".#####...", "..###....", ".##.#....", "##...#..."},
        {"..#####..", ".#######.", "#########", "##.###.##", "#########", ".#######.", "..#.#.#..", "..#####..", "..#.#.#.."},
        {"..#####..", ".#..#..#.", "#...#...#", "#...#...#", "#...###.#", "#.......#", "#.......#", ".#.....#.", "..#####.."}
    };

    StatsMod(String id, String name, boolean on, int dx, int dy) {
        super(id, name, on, dx, dy);
        w = 124;
        h = 100;
    }

    /** Used by the mixin: the vanilla sidebar is hidden while this module is on. */
    public static boolean hiding() {
        try {
            Hud.Mod m = Hud.get("stats");
            return m != null && m.on();
        } catch (Throwable t) {
            return false;
        }
    }

    private static String kindOf(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        if (l.contains("money") || l.contains("balance") || l.contains("coins")) return "money";
        if (l.contains("shard")) return "shards";
        if (l.contains("kill")) return "kills";
        if (l.contains("death")) return "deaths";
        if (l.contains("playtime") || l.contains("play time") || l.contains("time played")) return "time";
        return null;
    }

    private static String ascii(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0x20 && c <= 0x7E) sb.append(c);
        }
        return sb.toString().trim();
    }

    private static String valueOf(String s, String kind) {
        String v = s.replaceAll("(?i)(money|balance|coins|shards?|kills?|deaths?|play\\s*time|time played)", "");
        v = v.replace(":", "").replace("$", "").trim();
        return v;
    }

    private static int indexOf(String kind) {
        for (int i = 0; i < KINDS.length; i++) if (KINDS[i].equals(kind)) return i;
        return -1;
    }

    /** Reads the sidebar into rows {kind, value}. Returns false if the server has no sidebar. */
    private static boolean collect(MinecraftClient mc, List<String[]> out) {
        if (mc.world == null) return false;
        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return false;
        List<ScoreboardEntry> entries = new ArrayList<>(sb.getScoreboardEntries(obj));
        entries.removeIf(ScoreboardEntry::hidden);
        entries.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed()
            .thenComparing(ScoreboardEntry::owner, String.CASE_INSENSITIVE_ORDER));
        // The server draws its icons with private-use glyphs; keep plain text only.
        List<String> lines = new ArrayList<>();
        for (ScoreboardEntry e : entries) {
            Team team = sb.getScoreHolderTeam(e.owner());
            Text t = Team.decorateName(team, e.name());
            String s = ascii(t.getString());
            if (!s.isEmpty()) lines.add(s);
        }
        String[] vals = new String[KINDS.length];
        List<String> unlabeled = new ArrayList<>();
        for (String line : lines) {
            String k = kindOf(line);
            if (k != null) {
                int idx = indexOf(k);
                String v = valueOf(line, k);
                if (vals[idx] == null) vals[idx] = v.isEmpty() ? "-" : v;
            } else if (line.matches(".*\\d.*") && line.length() <= 16 && unlabeled.size() < 6) {
                unlabeled.add(line);
            }
        }
        for (String c : unlabeled) {
            int idx = -1;
            if (c.contains("$") && vals[0] == null) idx = 0;
            else if (c.matches("(?i).*\\d+\\s*[dh]\\b.*") && vals[4] == null) idx = 4;
            else {
                for (int i = 0; i < 4; i++) {
                    if (vals[i] == null) { idx = i; break; }
                }
            }
            if (idx >= 0) {
                String v = valueOf(c, KINDS[idx]);
                vals[idx] = v.isEmpty() ? "-" : v;
            }
        }
        boolean any = false;
        for (int i = 0; i < KINDS.length; i++) {
            if (vals[i] != null) { out.add(new String[]{KINDS[i], vals[i]}); any = true; }
        }
        if (!any) {
            for (int i = 0; i < lines.size() && i < 10; i++) out.add(new String[]{"", lines.get(i)});
        }
        return true;
    }

    private static void icon(DrawContext g, String kind, int x, int y, float a) {
        for (int k = 0; k < KINDS.length; k++) {
            if (!KINDS[k].equals(kind)) continue;
            int c = Gfx.argb(COLORS[k], a);
            String[] rows = ICONS[k];
            for (int r = 0; r < rows.length; r++) {
                for (int q = 0; q < rows[r].length(); q++) {
                    if (rows[r].charAt(q) == '#') g.fill(x + q, y + r, x + q + 1, y + r + 1, c);
                }
            }
            return;
        }
    }

    private static void head(DrawContext g, MinecraftClient mc, String name, int x, int y, int size, float a) {
        try {
            var nh = mc.getNetworkHandler();
            if (nh != null && mc.player != null) {
                var e = nh.getPlayerListEntry(mc.player.getUuid());
                if (e != null) {
                    PlayerSkinDrawer.draw(g, e.getSkinTextures(), x, y, size);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.error("stats.head", t);
        }
        Gfx.rrectH(g, x, y, size, size, 2, a);
        String ch = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        Gfx.text(g, ch, x + (size - Gfx.width(ch)) / 2f, y + (size - 8) / 2f, 1f, a, Gfx.BASE);
    }

    @Override
    void draw(DrawContext g, int x, int y, float a, boolean editor) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        List<String[]> rows = new ArrayList<>();
        boolean has = collect(mc, rows);
        if (!has) {
            if (!editor) return;
            rows.add(new String[]{"money", "800M"});
            rows.add(new String[]{"shards", "1K"});
            rows.add(new String[]{"kills", "1205"});
            rows.add(new String[]{"deaths", "328"});
            rows.add(new String[]{"time", "40d 8h"});
        }
        String name = mc.player.getName().getString();
        int need = 34 + Gfx.width(name) + 10;
        for (String[] r : rows) need = Math.max(need, 28 + Gfx.width(r[1]) + 12);
        w = Math.max(118, need);
        h = 33 + rows.size() * 15 + 4;

        g.fill(x, y, x + w, y + h, Gfx.argb(Gfx.PANEL, a * 0.88f));
        Gfx.outline(g, x, y, w, h, Gfx.argb(Gfx.LINE, a * 0.6f));
        g.fill(x, y, x + 2, y + h, Gfx.argb(Gfx.grad(0.5f), a));
        head(g, mc, name, x + 8, y + 6, 16, a);
        Gfx.text(g, name, x + 30, y + 10, 1f, a, Gfx.WHITE);
        Gfx.hGradient(g, x + 6, y + 27, w - 12, 1, a);
        for (int i = 0; i < rows.size(); i++) {
            int iy = y + 33 + i * 15;
            String[] r = rows.get(i);
            if (r[0].isEmpty()) {
                Gfx.text(g, r[1], x + 9, iy + 1.5f, 1f, a, Gfx.WHITE);
            } else {
                icon(g, r[0], x + 9, iy + 1, a);
                Gfx.text(g, r[1], x + 25, iy + 1.5f, 1f, a, Gfx.WHITE);
            }
        }
    }
}
