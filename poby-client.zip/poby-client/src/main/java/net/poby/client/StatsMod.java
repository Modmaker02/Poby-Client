package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Sidebar Stats: the server's scoreboard sidebar (Money, Shards, Kills, Deaths, Playtime...) redrawn as a Frost panel
 * with your head and name. Turning the module on also hides the vanilla sidebar (see InGameHudMixin).
 */
public final class StatsMod extends Hud.Mod {
    private static final String[] KINDS = {"money", "shards", "kills", "deaths", "time"};
    private static final int[] COLORS = {0x2EE56B, 0xB05CFF, 0xFF4D4D, 0xFF9F43, 0xFFD93D};
    private static final String[][] ICONS = {
        {"....#....", "..#####..", ".#..#..#.", ".#..#....", "..#####..", "....#..#.", ".#..#..#.", "..#####..", "....#...."},
        {"....#....", "....#....", "...###...", "#########", ".#######.", "..#####..", "..##.##..", ".##...##.", ".#.....#."},
        {".......##", "......###", ".....###.", "#...###..", "##.###...", ".#####...", "..###....", ".##.#....", "##...#..."},
        {"..#####..", ".#######.", "#########", "##.###.##", "#########", ".#######.", "..#.#.#..", "..#####..", "..#.#.#.."},
        {"..#####..", ".#..#..#.", "#...#...#", "#...#...#", "#...###.#", "#.......#", "#.......#", ".#.....#.", "..#####.."}
    };

    StatsMod(String id, String name, boolean on, int dx, int dy) {
        super(id, name, on, dx, dy);
        w = 124;
        h = 100;
    }

    /** Used by the mixin: the vanilla sidebar is hidden while this module is on. */
    public static boolean hiding() {
        try {
            Hud.Mod m = Hud.get("stats");
            return m != null && m.on();
        } catch (Throwable t) {
            return false;
        }
    }

    private static String kindOf(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        if (l.contains("money") || l.contains("balance") || l.contains("coins")) return "money";
        if (l.contains("shard")) return "shards";
        if (l.contains("kill")) return "kills";
        if (l.contains("death")) return "deaths";
        if (l.contains("playtime") || l.contains("play time") || l.contains("time played")) return "time";
        return null;
    }

    private static String ascii(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0x20 && c <= 0x7E) sb.append(c);
        }
        return sb.toString().trim();
    }

    private static String valueOf(String s, String kind) {
        String v = s.replaceAll("(?i)(money|balance|coins|shards?|kills?|deaths?|play\\s*time|time played)", "");
        v = v.replace(":", "").replace("$", "").trim();
        v = v.replaceAll("^[^0-9]+", "").trim(); // stray letters/symbols in front of the number (the "f")
        return v;
    }

    private static int indexOf(String kind) {
        for (int i = 0; i < KINDS.length; i++) if (KINDS[i].equals(kind)) return i;
        return -1;
    }

    /** Reads the sidebar into rows {kind, value}. Returns false if the server has no sidebar. */
    private static boolean collect(MinecraftClient mc, List<String[]> out) {
        if (mc.world == null) return false;
        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return false;
        List<ScoreboardEntry> entries = new ArrayList<>(sb.getScoreboardEntries(obj));
        entries.removeIf(ScoreboardEntry::hidden);
        entries.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed()
            .thenComparing(ScoreboardEntry::owner, String.CASE_INSENSITIVE_ORDER));
        // The server draws its icons with private-use glyphs; keep plain text only.
        List<String> lines = new ArrayList<>();
        for (ScoreboardEntry e : entries) {
            Team team = sb.getScoreHolderTeam(e.owner());
            Text t = Team.decorateName(team, e.name());
            String s = ascii(t.getString());
            if (!s.isEmpty()) lines.add(s);
        }
        String[] vals = new String[KINDS.length];
        List<String> unlabeled = new ArrayList<>();
        for (String line : lines) {
            String k = kindOf(line);
            if (k != null) {
                int idx = indexOf(k);
                String v = valueOf(line, k);
                if (vals[idx] == null) vals[idx] = v.isEmpty() ? "-" : v;
            } else if (line.matches(".*\\d.*") && line.length() <= 16 && unlabeled.size() < 6) {
                unlabeled.add(line);
            }
        }
        for (String c : unlabeled) {
            int idx = -1;
            if (c.contains("$") && vals[0] == null) idx = 0;
            else if (c.matches("(?i).*\\d+\\s*[dh]\\b.*") && vals[4] == null) idx = 4;
            else {
                for (int i = 0; i < 4; i++) {
                    if (vals[i] == null) { idx = i; break; }
                }
            }
            if (idx >= 0) {
                String v = valueOf(c, KINDS[idx]);
                vals[idx] = v.isEmpty() ? "-" : v;
            }
        }
        boolean any = false;
        for (int i = 0; i < KINDS.length; i++) {
            if (vals[i] != null) { out.add(new String[]{KINDS[i], vals[i]}); any = true; }
        }
        if (!any) {
            for (int i = 0; i < lines.size() && i < 10; i++) out.add(new String[]{"", lines.get(i)});
        }
        return true;
    }

    private static void icon(DrawContext g, String kind, int x, int y, float a) {
        for (int k = 0; k < KINDS.length; k++) {
            if (!KINDS[k].equals(kind)) continue;
            int c = Gfx.argb(COLORS[k], a);
            String[] rows = ICONS[k];
            for (int r = 0; r < rows.length; r++) {
                for (int q = 0; q < rows[r].length(); q++) {
                    if (rows[r].charAt(q) == '#') g.fill(x + q, y + r, x + q + 1, y + r + 1, c);
                }
            }
            return;
        }
    }

    private static void head(DrawContext g, MinecraftClient mc, String name, int x, int y, int size, float a) {
        try {
            var nh = mc.getNetworkHandler();
            if (nh != null && mc.player != null) {
                var e = nh.getPlayerListEntry(mc.player.getUuid());
                if (e != null) {
                    PlayerSkinDrawer.draw(g, e.getSkinTextures(), x, y, size);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.error("stats.head", t);
        }
        Gfx.rrectH(g, x, y, size, size, 2, a);
        String ch = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        Gfx.text(g, ch, x + (size - Gfx.width(ch)) / 2f, y + (size - 8) / 2f, 1f, a, Gfx.BASE);
    }

    private static final int DARK = 0x080E1C;

    private static String find(List<String[]> rows, String kind) {
        for (String[] r : rows) if (r[0].equals(kind)) return r[1];
        return "-";
    }

    private static void tile(DrawContext g, int idx, String val, int tx, int ty, int tw, int th, float a, boolean wide) {
        int c = COLORS[idx];
        Gfx.round(g, tx, ty, tw, th, 7, Gfx.lerp(DARK, c, 0.45f), Gfx.lerp(DARK, c, 0.12f), a * 0.95f);
        int tint = Gfx.lerp(Gfx.WHITE, c, 0.4f);
        String label = LABELS[idx];
        if (!wide) {
            icon(g, KINDS[idx], tx + 7, ty + 6, a);
            Gfx.text(g, label, tx + tw - 6 - Gfx.width(label) * 0.6f, ty + 7, 0.6f, a, tint);
            float sc = 1.4f;
            while (Gfx.width(val) * sc > tw - 12 && sc > 0.8f) sc -= 0.1f;
            Gfx.text(g, val, tx + 7, ty + 21, sc, a, Gfx.WHITE);
        } else {
            icon(g, KINDS[idx], tx + 8, ty + 8, a);
            Gfx.text(g, val, tx + 24, ty + 8, 1.25f, a, Gfx.WHITE);
            Gfx.text(g, label, tx + tw - 8 - Gfx.width(label) * 0.6f, ty + 10, 0.6f, a, tint);
        }
    }

    private static final String[] LABELS = {"MONEY", "SHARDS", "KILLS", "DEATHS", "PLAYTIME"};

    @Override
    void draw(DrawContext g, int x, int y, float a, boolean editor) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        List<String[]> rows = new ArrayList<>();
        boolean has = collect(mc, rows);
        if (!has) {
            if (!editor) return;
            rows.add(new String[]{"money", "800M"});
            rows.add(new String[]{"shards", "1K"});
            rows.add(new String[]{"kills", "1205"});
            rows.add(new String[]{"deaths", "328"});
            rows.add(new String[]{"time", "40d 8h"});
        }
        String name = mc.player.getName().getString();
        int hw = 112;
        w = hw;

        // unknown server layout: just show its lines in a rounded panel
        if (!rows.isEmpty() && rows.get(0)[0].isEmpty()) {
            h = 24 + rows.size() * 12 + 6;
            Gfx.round(g, x, y, hw, 20, 10, Gfx.PANEL, a * 0.92f);
            head(g, mc, name, x + 3, y + 3, 14, a);
            Gfx.text(g, name, x + 22, y + 6, 1f, a, Gfx.WHITE);
            Gfx.round(g, x, y + 24, hw, rows.size() * 12 + 6, 7, Gfx.PANEL, a * 0.88f);
            for (int i = 0; i < rows.size(); i++) Gfx.text(g, rows.get(i)[1], x + 7, y + 28 + i * 12, 0.9f, a, Gfx.WHITE);
            return;
        }

        h = 24 + 44 * 2 + 26;
        Gfx.round(g, x, y, hw, 20, 10, Gfx.PANEL, a * 0.92f);
        head(g, mc, name, x + 3, y + 3, 14, a);
        Gfx.text(g, name, x + 22, y + 6, 1f, a, Gfx.WHITE);
        int tw = (hw - 4) / 2;
        for (int i = 0; i < 4; i++) {
            tile(g, i, find(rows, KINDS[i]), x + (i % 2) * (tw + 4), y + 24 + (i / 2) * 44, tw, 40, a, false);
        }
        tile(g, 4, find(rows, "time"), x, y + 24 + 88, hw, 26, a, true);
    }
}
