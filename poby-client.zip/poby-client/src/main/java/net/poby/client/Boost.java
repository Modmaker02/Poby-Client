package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;

import java.util.function.Function;

/**
 * FPS features that change game options while their module is on and put the old value back when it is turned off.
 * The old values are saved in the Poby config, so they also survive a restart.
 */
public final class Boost {
    private Boost() {}

    private static <T> void force(String key, SimpleOption<T> opt, T val, Function<T, String> ser) {
        if (!Config.I.savedOpts.containsKey(key)) {
            Config.I.savedOpts.put(key, ser.apply(opt.getValue()));
            Config.save();
        }
        if (!opt.getValue().equals(val)) opt.setValue(val);
    }

    private static <T> void restore(String key, SimpleOption<T> opt, Function<String, T> parse) {
        String s = Config.I.savedOpts.remove(key);
        if (s == null) return;
        try {
            opt.setValue(parse.apply(s));
        } catch (Throwable t) {
            Log.error("boost.restore", t);
        }
        Config.save();
    }

    public static void tick(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (o == null) return;
        try {
            if (Hud.get("uncapfps").on()) {
                force("fps", o.getMaxFps(), 260, Object::toString);
                force("vsync", o.getEnableVsync(), false, Object::toString);
            } else {
                restore("fps", o.getMaxFps(), Integer::parseInt);
                restore("vsync", o.getEnableVsync(), Boolean::parseBoolean);
            }
            if (Hud.get("lowparticles").on()) force("particles", o.getParticles(), ParticlesMode.MINIMAL, ParticlesMode::name);
            else restore("particles", o.getParticles(), ParticlesMode::valueOf);

            if (Hud.get("noshadows").on()) force("shadows", o.getEntityShadows(), false, Object::toString);
            else restore("shadows", o.getEntityShadows(), Boolean::parseBoolean);

            if (Hud.get("entitydist").on()) force("entdist", o.getEntityDistanceScaling(), 0.5, Object::toString);
            else restore("entdist", o.getEntityDistanceScaling(), Double::parseDouble);
        } catch (Throwable t) {
            Log.error("boost.tick", t);
        }
    }
}
