package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

import java.util.function.Function;

/**
 * FPS features that change game options while their module is on and put the old value back when it is turned off.
 * The old values are saved in the Poby config, so they also survive a restart.
 */
public final class Boost {
    private Boost() {}

    private static <T> void force(String key, SimpleOption<T> opt, T val, Function<T, String> ser) {
        if (!Config.I.savedOpts.containsKey(key)) {
            Config.I.savedOpts.put(key, ser.apply(opt.getValue()));
            Config.save();
        }
        if (!opt.getValue().equals(val)) opt.setValue(val);
    }

    private static <T> void restore(String key, SimpleOption<T> opt, Function<String, T> parse) {
        String s = Config.I.savedOpts.remove(key);
        if (s == null) return;
        try {
            opt.setValue(parse.apply(s));
        } catch (Throwable t) {
            Log.error("boost.restore", t);
        }
        Config.save();
    }

    /** Sets an enum option to its last value (for particles that is "minimal"); the enum class is never named. */
    @SuppressWarnings("unchecked")
    private static <T> void forceLast(String key, SimpleOption<T> opt) {
        T cur = opt.getValue();
        if (!(cur instanceof Enum<?> e)) return;
        Object[] all = e.getDeclaringClass().getEnumConstants();
        force(key, opt, (T) all[all.length - 1], v -> String.valueOf(((Enum<?>) v).ordinal()));
    }

    @SuppressWarnings("unchecked")
    private static <T> void restoreEnum(String key, SimpleOption<T> opt) {
        T cur = opt.getValue();
        if (!(cur instanceof Enum<?> e)) {
            Config.I.savedOpts.remove(key);
            return;
        }
        Object[] all = e.getDeclaringClass().getEnumConstants();
        restore(key, opt, s -> (T) all[Math.max(0, Math.min(all.length - 1, Integer.parseInt(s)))]);
    }

    public static void tick(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (o == null) return;
        try {
            if (Hud.get("uncapfps").on()) {
                force("fps", o.getMaxFps(), 260, Object::toString);
                force("vsync", o.getEnableVsync(), false, Object::toString);
            } else {
                restore("fps", o.getMaxFps(), Integer::parseInt);
                restore("vsync", o.getEnableVsync(), Boolean::parseBoolean);
            }
            if (Hud.get("lowparticles").on()) forceLast("particles", o.getParticles());
            else restoreEnum("particles", o.getParticles());

            if (Hud.get("noshadows").on()) force("shadows", o.getEntityShadows(), false, Object::toString);
            else restore("shadows", o.getEntityShadows(), Boolean::parseBoolean);

            if (Hud.get("entitydist").on()) force("entdist", o.getEntityDistanceScaling(), 0.5, Object::toString);
            else restore("entdist", o.getEntityDistanceScaling(), Double::parseDouble);
        } catch (Throwable t) {
            Log.error("boost.tick", t);
        }
    }
}
