package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PobyMenuScreen extends PobyScreen {
    static int tab = 0, preset = 0;
    static final int PW = 560, PH = 330;
    static final String[] KEY_NAMES = {"Open Menu", "HUD Editor", "Toggle Sprint", "Full Bright"};

    private final Screen parent;
    private int listening = -1, px, py, cx, cw;
    private boolean menuHeld, dragSlider;
    private final boolean[] prev = new boolean[350];
    private TextFieldWidget hexA, hexB, custom;

    public PobyMenuScreen() { this(null); }

    public PobyMenuScreen(Screen parent) {
        super(Text.literal("Poby Client"));
        this.parent = parent;
        menuHeld = Keys.down(MinecraftClient.getInstance().getWindow().getHandle(), Config.I.keyMenu);
    }

    private int getKey(int i) {
        Config c = Config.I;
        return switch (i) { case 0 -> c.keyMenu; case 1 -> c.keyEditor; case 2 -> c.keySprint; default -> c.keyBright; };
    }

    private void setKey(int i, int v) {
        Config c = Config.I;
        switch (i) {
            case 0 -> c.keyMenu = v;
            case 1 -> c.keyEditor = v;
            case 2 -> c.keySprint = v;
            default -> c.keyBright = v;
        }
    }

    private static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    private static int parse(String s) {
        try {
            s = s.trim();
            if (s.startsWith("#")) s = s.substring(1);
            return s.length() == 6 ? Integer.parseInt(s, 16) : -1;
        } catch (Exception e) { return -1; }
    }

    private static String abbr(String id) {
        return switch (id) {
            case "fps" -> "FPS"; case "clock" -> "CLK"; case "directions" -> "DIR"; case "memory" -> "MEM";
            case "customtext" -> "TXT"; case "cps" -> "CPS"; case "ping" -> "MS"; case "coords" -> "XYZ";
            case "togglesprint" -> "SPR"; case "fullbright" -> "BRT"; case "armor" -> "ARM"; default -> "KEY";
        };
    }

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
        cx = px + 20;
        cw = PW - 40;
    }

    private TextFieldWidget field(int x, int y, int w, String placeholder) {
        return new TextFieldWidget(textRenderer, (int) (x * s), (int) (y * s), (int) (w * s), Math.max(14, (int) (16 * s)), Text.literal(placeholder));
    }

    private void rebuild() { clearChildren(); init(); }

    @Override
    protected void init() {
        layout();
        if (tab == 1) {
            int rx = cx + 264;
            hexA = field(rx + 10, py + 122, 112, "Start");
            hexA.setMaxLength(7);
            hexA.setText(hex(Config.I.colorA));
            hexA.setChangedListener(v -> { int c = parse(v); if (c >= 0) { Config.I.colorA = c; preset = -1; } });
            hexB = field(rx + 134, py + 122, 112, "End");
            hexB.setMaxLength(7);
            hexB.setText(hex(Config.I.colorB));
            hexB.setChangedListener(v -> { int c = parse(v); if (c >= 0) { Config.I.colorB = c; preset = -1; } });
            custom = field(rx + 10, py + 218, 236, "Custom text");
            custom.setMaxLength(40);
            custom.setText(Config.I.customText);
            custom.setChangedListener(v -> Config.I.customText = v);
            addDrawableChild(hexA);
            addDrawableChild(hexB);
            addDrawableChild(custom);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return listening < 0; }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }

    @Override
    protected void onFrame() {
        boolean menuNow = Keys.down(win, Config.I.keyMenu);
        if (listening >= 0) {
            for (int k = 32; k <= 348; k++) {
                if (!Keys.valid(k)) continue;
                boolean d = Keys.down(win, k);
                if (d && !prev[k]) {
                    if (k != GLFW.GLFW_KEY_ESCAPE) setKey(listening, k == GLFW.GLFW_KEY_DELETE ? -1 : k);
                    listening = -1;
                    break;
                }
                prev[k] = d;
            }
        } else if (menuNow && !menuHeld && !(getFocused() instanceof TextFieldWidget tf && tf.isFocused())) {
            act(this::close);
        }
        menuHeld = Keys.down(win, Config.I.keyMenu);
        if (!down) dragSlider = false;
    }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.glass(g, px, py, PW, PH, 16, 0.80f, 0f);
        Gfx.hGradient(g, px + 18, py + 1, PW - 36, 1, 0.9f);
    }

    @Override
    protected void paintFront(DrawContext g) {
        // header
        Gfx.text(g, "POBY", px + 20, py + 19, 1.7f, 1f, -1);
        int tx = px + (PW - 248) / 2;
        Gfx.rrect(g, tx, py + 14, 248, 26, 13, Gfx.argb(0xFFFFFF, 0.10f));
        String[] tn = {"Modules", "Preferences", "Keybinds"};
        for (int i = 0; i < 3; i++) {
            int x = tx + 4 + i * 80, y = py + 17;
            boolean sel = tab == i, hv = hover(x, y, 80, 20);
            if (sel) Gfx.rrectH(g, x, y, 80, 20, 10, 1f);
            else if (hv) Gfx.rrect(g, x, y, 80, 20, 10, Gfx.argb(0xFFFFFF, 0.10f));
            centered(g, tn[i], x + 40, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv && !sel) {
                final int idx = i;
                act(() -> { tab = idx; listening = -1; rebuild(); });
            }
        }
        if (button(g, "HUD Editor", px + PW - 138, py + 14, 84, 26, false)) act(() -> client.setScreen(new HudEditorScreen(this)));
        if (iconButton(g, "x", px + PW - 46, py + 14, 26)) act(this::close);

        if (tab == 0) modules(g);
        else if (tab == 1) prefs(g);
        else keys(g);

        Gfx.text(g, Keys.name(Config.I.keyMenu) + " to close", cx, py + PH - 18, 1f, 0.7f, Gfx.MUTED);
    }

    private void modules(DrawContext g) {
        Gfx.text(g, Hud.MODS.size() + " modules  -  click a tile to enable it", cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        int w = (cw - 24) / 4, h = 62, i = 0;
        for (Hud.Mod m : Hud.MODS) {
            int x = cx + (i % 4) * (w + 8), y = py + 66 + (i / 4) * 70;
            boolean hv = hover(x, y, w, h), on = m.on();
            float k = ease("t" + m.id, hv, 14f);
            if (on) {
                Gfx.rrectH(g, x - 1, y - 1, w + 2, h + 2, 12, 1f);
                Gfx.rrect(g, x, y, w, h, 11, Gfx.argb(Gfx.BASE, 0.93f));
                Gfx.rrect(g, x, y, w, h, 11, Gfx.argb(0xFFFFFF, 0.04f * k));
            } else {
                Gfx.glass(g, x, y, w, h, 12, 0.35f, 0.05f * k);
            }
            if (on) Gfx.rrectH(g, x + 10, y + 10, 28, 28, 14, 1f);
            else Gfx.rrect(g, x + 10, y + 10, 28, 28, 14, Gfx.argb(0xFFFFFF, 0.12f));
            String ab = abbr(m.id);
            Gfx.text(g, ab, x + 24 - Gfx.width(ab) * 0.75f / 2f, y + 21, 0.75f, 1f, on ? Gfx.BASE : Gfx.WHITE);
            toggle(g, x + w - 38, y + 13, on, "m" + m.id);
            Gfx.text(g, m.name, x + 10, y + 42, 1f, 1f, Gfx.WHITE);
            Gfx.text(g, on ? "Enabled" : "Disabled", x + 10, y + 52, 0.8f, 1f, on ? Gfx.argb(Config.I.colorB, 1f) & 0xFFFFFF : Gfx.MUTED);
            if (pressed && hv) m.set(!on);
            i++;
        }
    }

    private boolean card(DrawContext g, int x, int y, int w, int h, String label) {
        boolean hv = hover(x, y, w, h);
        Gfx.glass(g, x, y, w, h, 10, 0.35f, hv ? 0.04f : 0f);
        if (label != null) Gfx.text(g, label, x + 10, y + 5, 0.9f, 1f, Gfx.MUTED);
        return hv;
    }

    private void prefs(DrawContext g) {
        Config c = Config.I;
        String tname = preset >= 0 ? Gfx.PRESETS[preset].name() : "Custom";
        Gfx.text(g, "Theme: " + tname, cx, py + 54, 1f, 0.9f, Gfx.MUTED);
        int n = Gfx.PRESETS.length, chw = (cw - (n - 1) * 8) / n;
        for (int i = 0; i < n; i++) {
            Gfx.Preset p = Gfx.PRESETS[i];
            int x = cx + i * (chw + 8), y = py + 68;
            boolean hv = hover(x, y, chw, 24);
            if (preset == i) Gfx.rrect(g, x - 2, y - 2, chw + 4, 28, 14, 0xFFFFFFFF);
            else if (hv) Gfx.rrect(g, x - 1, y - 1, chw + 2, 26, 13, 0x99FFFFFF);
            Gfx.rrectGrad(g, x, y, chw, 24, 12, p.a(), p.b(), 1f);
            if (pressed && hv) {
                c.colorA = p.a();
                c.colorB = p.b();
                hexA.setText(hex(p.a()));
                hexB.setText(hex(p.b()));
                preset = i;
            }
        }
        int y1 = py + 104, y2 = py + 152, y3 = py + 200, lw = 256, rx = cx + 264;

        // left column
        boolean h1 = card(g, cx, y1, lw, 40, null);
        Gfx.text(g, "Gradient Text", cx + 12, y1 + 16, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y1 + 13, c.gradientText, "gt");
        if (h1 && pressed) c.gradientText = !c.gradientText;

        boolean h2 = card(g, cx, y2, lw, 40, null);
        Gfx.text(g, "Animations", cx + 12, y2 + 16, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y2 + 13, c.animations, "an");
        if (h2 && pressed) c.animations = !c.animations;

        card(g, cx, y3, lw, 40, null);
        Gfx.text(g, "Font", cx + 12, y3 + 16, 1f, 1f, Gfx.WHITE);
        String[] fn = {"Smooth", "Bold"};
        for (int i = 0; i < 2; i++) {
            int x = cx + lw - 138 + i * 64, y = y3 + 10;
            boolean sel = c.boldFont == (i == 1), hv = hover(x, y, 62, 20);
            if (sel) Gfx.rrectH(g, x, y, 62, 20, 10, 1f);
            else Gfx.rrect(g, x, y, 62, 20, 10, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
            centered(g, fn[i], x + 31, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) c.boldFont = i == 1;
        }

        int y4 = py + 248;
        boolean h4 = card(g, cx, y4, lw, 40, null);
        Gfx.text(g, "Theme Minecraft menus", cx + 12, y4 + 16, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y4 + 13, c.themeMenus, "tm");
        if (h4 && pressed) c.themeMenus = !c.themeMenus;

        // right column
        card(g, rx, y1, lw, 40, "Gradient colors (hex)");
        card(g, rx, y2, lw, 40, null);
        Gfx.text(g, "Speed", rx + 12, y2 + 16, 1f, 1f, Gfx.WHITE);
        int sx = rx + 62, sw = 130, sy = y2;
        float v = Math.max(0f, Math.min(1f, (c.animSpeed - 0.25f) / 2.75f));
        if (pressed && hover(sx - 6, sy, sw + 12, 40)) dragSlider = true;
        if (dragSlider) {
            v = Math.max(0f, Math.min(1f, (mx - sx) / (float) sw));
            c.animSpeed = 0.25f + v * 2.75f;
        }
        Gfx.rrect(g, sx, sy + 18, sw, 4, 2, Gfx.argb(0xFFFFFF, 0.18f));
        Gfx.rrectH(g, sx, sy + 18, Math.max(4, (int) (sw * v)), 4, 2, 1f);
        Gfx.rrect(g, sx + (int) (sw * v) - 6, sy + 14, 12, 12, 6, 0xFFFFFFFF);
        Gfx.text(g, String.format("%.2fx", c.animSpeed), sx + sw + 10, sy + 16, 1f, 1f, Gfx.WHITE);
        card(g, rx, y3, lw, 40, "Custom text (Custom Text HUD)");
    }

    private void keys(DrawContext g) {
        Gfx.text(g, "Click a key, then press the new one.  ESC cancels, DEL unbinds.", cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        for (int i = 0; i < 4; i++) {
            int y = py + 66 + i * 48;
            card(g, cx, y, cw, 40, null);
            Gfx.text(g, KEY_NAMES[i], cx + 14, y + 16, 1f, 1f, Gfx.WHITE);
            int kx = cx + cw - 152, ky = y + 8;
            boolean hv = hover(kx, ky, 140, 24), ls = listening == i;
            if (ls) Gfx.rrectH(g, kx, ky, 140, 24, 12, 1f);
            else {
                Gfx.rrect(g, kx, ky, 140, 24, 12, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
                Gfx.rrectStroke(g, kx, ky, 140, 24, 12, Gfx.argb(0xFFFFFF, 0.25f));
            }
            String label = ls ? "Press a key..." : Keys.name(getKey(i));
            centered(g, label, kx + 70, ky + 8, 1f, 1f, ls ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) {
                listening = i;
                for (int k = 32; k <= 348; k++) if (Keys.valid(k)) prev[k] = Keys.down(win, k);
            }
        }
    }
}
