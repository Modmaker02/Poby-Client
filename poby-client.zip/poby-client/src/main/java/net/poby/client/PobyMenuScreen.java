package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PobyMenuScreen extends PobyScreen {
    static int tab = 0;
    static final int PW = 640, PH = 370, SB = 132;
    static final String[] KEY_NAMES = {"Open Menu", "HUD Editor", "Toggle Sprint", "Full Bright"};
    static final String[] LOAD_STYLES = {"Bar", "Dots", "Pulse"};

    private final Screen parent;
    private int listening = -1, px, py, cx, cw, lw, rx, ct;
    private final java.util.List<int[]> frames = new java.util.ArrayList<>();
    private boolean menuHeld, dragSlider;
    private final boolean[] prev = new boolean[350];
    private TextFieldWidget hexA, hexB, titleField, subField;

    public PobyMenuScreen() { this(null); }

    public PobyMenuScreen(Screen parent) {
        super(Text.literal("Poby Client"));
        this.parent = parent;
        menuHeld = Keys.down(MinecraftClient.getInstance().getWindow().getHandle(), Config.I.keyMenu);
    }

    private int getKey(int i) {
        Config c = Config.I;
        return switch (i) { case 0 -> c.keyMenu; case 1 -> c.keyEditor; case 2 -> c.keySprint; default -> c.keyBright; };
    }

    private void setKey(int i, int v) {
        Config c = Config.I;
        switch (i) {
            case 0 -> c.keyMenu = v;
            case 1 -> c.keyEditor = v;
            case 2 -> c.keySprint = v;
            default -> c.keyBright = v;
        }
    }

    private static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    private static int parse(String s) {
        try {
            s = s.trim();
            if (s.startsWith("#")) s = s.substring(1);
            return s.length() == 6 ? Integer.parseInt(s, 16) : -1;
        } catch (Exception e) { return -1; }
    }

    private static String abbr(String id) {
        return switch (id) {
            case "fps" -> "FPS"; case "clock" -> "CLK"; case "directions" -> "DIR"; case "memory" -> "MEM";
            case "customtext" -> "TXT"; case "cps" -> "CPS"; case "ping" -> "MS"; case "coords" -> "XYZ";
            case "togglesprint" -> "SPR"; case "fullbright" -> "BRT"; case "fpsboost" -> "FPS+";
            case "armor" -> "ARM"; default -> "KEY";
        };
    }

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
        cx = px + SB + 18;
        cw = PW - SB - 36;
        lw = (cw - 10) / 2;
        rx = cx + lw + 10;
        ct = py + 62;
    }

    @Override
    protected float uiScale() { return Math.min(1f, Math.min(width / (PW + 20f), height / (PH + 20f))); }

    private int currentPreset() {
        for (int i = 0; i < Gfx.PRESETS.length; i++) {
            if (Gfx.PRESETS[i].a() == (Config.I.colorA & 0xFFFFFF) && Gfx.PRESETS[i].b() == (Config.I.colorB & 0xFFFFFF)) return i;
        }
        return -1;
    }

    private TextFieldWidget field(int x, int y, int w, String placeholder) {
        frames.add(new int[]{x, y, w});
        return new TextFieldWidget(textRenderer, (int) (x * s), (int) (y * s), (int) (w * s), Math.max(14, (int) (16 * s)), Text.literal(placeholder));
    }

    private void rebuild() { clearChildren(); init(); }

    @Override
    protected void init() {
        layout();
        frames.clear();
        if (tab == 1) {
            int fw = (lw - 28) / 2, fy = ct + 62 + 16;
            hexA = field(rx + 10, fy, fw, "Start");
            hexA.setMaxLength(7);
            hexA.setText(hex(Config.I.colorA));
            hexA.setChangedListener(v -> { int c = parse(v); if (c >= 0) Config.I.colorA = c; });
            hexB = field(rx + 18 + fw, fy, fw, "End");
            hexB.setMaxLength(7);
            hexB.setText(hex(Config.I.colorB));
            hexB.setChangedListener(v -> { int c = parse(v); if (c >= 0) Config.I.colorB = c; });
            addDrawableChild(hexA);
            addDrawableChild(hexB);
        } else if (tab == 3) {
            int fy = ct + 14 + 46 + 16;
            titleField = field(cx + 10, fy, lw - 20, "Title");
            titleField.setMaxLength(24);
            titleField.setText(Config.I.loadTitle);
            titleField.setChangedListener(v -> Config.I.loadTitle = v);
            subField = field(rx + 10, fy, lw - 20, "Message");
            subField.setMaxLength(40);
            subField.setText(Config.I.loadSub);
            subField.setChangedListener(v -> Config.I.loadSub = v);
            addDrawableChild(titleField);
            addDrawableChild(subField);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return listening < 0; }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }

    @Override
    protected void onFrame() {
        boolean menuNow = Keys.down(win, Config.I.keyMenu);
        if (listening >= 0) {
            for (int k = 32; k <= 348; k++) {
                if (!Keys.valid(k)) continue;
                boolean d = Keys.down(win, k);
                if (d && !prev[k]) {
                    if (k != GLFW.GLFW_KEY_ESCAPE) setKey(listening, k == GLFW.GLFW_KEY_DELETE ? -1 : k);
                    listening = -1;
                    break;
                }
                prev[k] = d;
            }
        } else if (menuNow && !menuHeld && !(getFocused() instanceof TextFieldWidget tf && tf.isFocused())) {
            act(this::close);
        }
        menuHeld = Keys.down(win, Config.I.keyMenu);
        if (!down) dragSlider = false;
    }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.window(g, px, py, PW, PH);
        g.fill(px + 1, py + 2, px + SB, py + PH - 1, Gfx.argb(Gfx.PANEL, 1f));
        g.fill(px + SB, py + 2, px + SB + 2, py + PH - 1, Gfx.argb(Gfx.accent(), 0.9f));
        int fh = (int) (Math.max(14, (int) (16 * s)) / s);
        for (int[] f : frames) Gfx.outline(g, f[0] - 1, f[1] - 1, f[2] + 2, fh + 2, Gfx.argb(Gfx.accent(), 0.9f));
    }

    @Override
    protected void paintFront(DrawContext g) {
        // ---- sidebar
        Gfx.spaced(g, "POBY", px + SB / 2f, py + 18, 2.2f, 5f, 1f, Gfx.WHITE);
        Gfx.spaced(g, "CLIENT", px + SB / 2f, py + 41, 1f, 4f, 0.9f, Gfx.MUTED);
        String[] tn = {"Modules", "Preferences", "Keybinds", "Loading"};
        for (int i = 0; i < 4; i++) {
            int x = px + 8, y = py + 68 + i * 30, w = SB - 16, h = 26;
            boolean sel = tab == i, hv = hover(x, y, w, h);
            if (sel) {
                g.fill(x, y, x + w, y + h, Gfx.argb(Gfx.BTN, 1f));
                g.fill(x, y, x + 3, y + h, Gfx.argb(Gfx.accent(), 1f));
            } else if (hv) {
                g.fill(x, y, x + w, y + h, Gfx.argb(Gfx.BTN, 0.5f));
            }
            Gfx.text(g, tn[i], x + 14, y + 9, 1f, 1f, sel || hv ? Gfx.WHITE : Gfx.MUTED);
            if (pressed && hv && !sel) {
                final int idx = i;
                act(() -> { tab = idx; listening = -1; rebuild(); });
            }
        }
        if (button(g, "HUD Editor", px + 10, py + PH - 62, SB - 20, 24, false)) act(() -> client.setScreen(new HudEditorScreen(this)));
        String close = Keys.name(Config.I.keyMenu) + " to close";
        Gfx.text(g, close, px + SB / 2f - Gfx.width(close) * 0.85f / 2f, py + PH - 26, 0.85f, 0.8f, Gfx.MUTED);

        // ---- header
        String[] sub = {Hud.MODS.size() + " modules  -  click a tile to enable it", "Theme, colours and fonts",
            "Click a key, then press the new one.  ESC cancels, DEL unbinds.", "Startup screen, loading terrain and world loading"};
        Gfx.text(g, tn[tab], cx, py + 16, 1.5f, 1f, -1);
        Gfx.text(g, sub[tab], cx, py + 38, 0.9f, 1f, Gfx.MUTED);
        if (iconButton(g, "x", px + PW - 18 - 24, py + 14, 24)) act(this::close);

        if (tab == 0) modules(g);
        else if (tab == 1) prefs(g);
        else if (tab == 2) keys(g);
        else loading(g);
    }

    private void modules(DrawContext g) {
        int w = (cw - 16) / 3, h = 50, i = 0, acc = Gfx.accent();
        for (Hud.Mod m : Hud.MODS) {
            int x = cx + (i % 3) * (w + 8), y = ct + (i / 3) * 56;
            boolean hv = hover(x, y, w, h), on = m.on(), custom = m.id.equals("customtext");
            float k = ease("t" + m.id, hv, 14f);
            g.fill(x, y, x + w, y + h, Gfx.argb(on ? 0x0F2F55 : Gfx.BTN, on ? 0.95f : 0.6f));
            Gfx.outline(g, x, y, w, h, on ? Gfx.argb(acc, 0.9f) : Gfx.argb(Gfx.LINE, 0.55f + 0.45f * k));
            if (on) g.fill(x, y, x + 3, y + h, Gfx.argb(acc, 1f));
            g.fill(x + 10, y + 9, x + 36, y + 35, on ? Gfx.argb(acc, 1f) : Gfx.argb(0xFFFFFF, 0.10f));
            String ab = abbr(m.id);
            Gfx.text(g, ab, x + 23 - Gfx.width(ab) * 0.75f / 2f, y + 19, 0.75f, 1f, on ? Gfx.BASE : Gfx.WHITE);
            Gfx.text(g, m.name, x + 44, y + 10, 1f, 1f, Gfx.WHITE);
            String status = custom ? Config.I.texts.size() + " texts - edit" : (on ? "Enabled" : "Disabled");
            Gfx.text(g, status, x + 44, y + 24, 0.8f, 1f, custom || on ? (Config.I.colorB & 0xFFFFFF) : Gfx.MUTED);
            toggle(g, x + w - 38, y + h - 20, on, "m" + m.id);
            if (pressed && hv) {
                if (custom && mx < x + w - 44) act(() -> client.setScreen(new PobyCustomTextScreen(this)));
                else m.set(!on);
            }
            i++;
        }
    }

    private boolean card(DrawContext g, int x, int y, int w, int h, String label) {
        boolean hv = hover(x, y, w, h);
        Gfx.glass(g, x, y, w, h, 0, 0.35f, hv ? 0.04f : 0f);
        if (label != null) Gfx.text(g, label, x + 10, y + 5, 0.9f, 1f, Gfx.MUTED);
        return hv;
    }

    private void prefs(DrawContext g) {
        Config c = Config.I;
        int preset = currentPreset();
        String tname = preset >= 0 ? Gfx.PRESETS[preset].name() : "Custom";
        Gfx.text(g, "Theme: " + tname, cx, ct, 1f, 0.9f, Gfx.MUTED);
        int n = Gfx.PRESETS.length, per = 7, chw = (cw - (per - 1) * 8) / per;
        for (int i = 0; i < n; i++) {
            Gfx.Preset p = Gfx.PRESETS[i];
            int x = cx + (i % per) * (chw + 8), y = ct + 14 + (i / per) * 22;
            boolean hv = hover(x, y, chw, 16);
            if (preset == i) Gfx.outline(g, x - 2, y - 2, chw + 4, 20, 0xFFFFFFFF);
            else if (hv) Gfx.outline(g, x - 1, y - 1, chw + 2, 18, 0x99FFFFFF);
            Gfx.rrectGrad(g, x, y, chw, 16, 2, p.a(), p.b(), 1f);
            if (pressed && hv) {
                c.colorA = p.a();
                c.colorB = p.b();
                hexA.setText(hex(p.a()));
                hexB.setText(hex(p.b()));
            }
        }
        int y1 = ct + 62, y2 = y1 + 44, y3 = y2 + 44, y4 = y3 + 44;

        boolean h1 = card(g, cx, y1, lw, 38, null);
        Gfx.text(g, "Gradient Text", cx + 12, y1 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y1 + 12, c.gradientText, "gt");
        if (h1 && pressed) c.gradientText = !c.gradientText;

        boolean h2 = card(g, cx, y2, lw, 38, null);
        Gfx.text(g, "Animations", cx + 12, y2 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y2 + 12, c.animations, "an");
        if (h2 && pressed) c.animations = !c.animations;

        card(g, cx, y3, lw, 38, null);
        Gfx.text(g, "Font", cx + 12, y3 + 15, 1f, 1f, Gfx.WHITE);
        String[] fn = {"Smooth", "Bold"};
        for (int i = 0; i < 2; i++) {
            int x = cx + lw - 138 + i * 64, y = y3 + 9;
            boolean sel = c.boldFont == (i == 1), hv = hover(x, y, 62, 20);
            if (sel) Gfx.rrectH(g, x, y, 62, 20, 2, 1f);
            else g.fill(x, y, x + 62, y + 20, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
            centered(g, fn[i], x + 31, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) c.boldFont = i == 1;
        }

        boolean h4 = card(g, cx, y4, lw, 38, null);
        Gfx.text(g, "Theme Minecraft menus", cx + 12, y4 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y4 + 12, c.themeMenus, "tm");
        if (h4 && pressed) c.themeMenus = !c.themeMenus;

        // right column
        card(g, rx, y1, lw, 38, "Gradient colors (hex)");

        card(g, rx, y2, lw, 38, null);
        Gfx.text(g, "Speed", rx + 12, y2 + 15, 1f, 1f, Gfx.WHITE);
        int sx = rx + 62, sw = lw - 130, sy = y2;
        float v = Math.max(0f, Math.min(1f, (c.animSpeed - 0.25f) / 2.75f));
        if (pressed && hover(sx - 6, sy, sw + 12, 38)) dragSlider = true;
        if (dragSlider) {
            v = Math.max(0f, Math.min(1f, (mx - sx) / (float) sw));
            c.animSpeed = 0.25f + v * 2.75f;
        }
        g.fill(sx, sy + 17, sx + sw, sy + 21, Gfx.argb(0xFFFFFF, 0.18f));
        Gfx.rrectH(g, sx, sy + 17, Math.max(4, (int) (sw * v)), 4, 2, 1f);
        int kx = sx + (int) (sw * v) - 5;
        g.fill(kx, sy + 12, kx + 10, sy + 26, 0xFFFFFFFF);
        Gfx.text(g, String.format("%.2fx", c.animSpeed), sx + sw + 12, sy + 15, 1f, 1f, Gfx.WHITE);

        boolean h3 = card(g, rx, y3, lw, 38, null);
        Gfx.text(g, "Menus on servers", rx + 12, y3 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, rx + lw - 40, y3 + 12, c.themeOnServers, "ts");
        if (h3 && pressed) c.themeOnServers = !c.themeOnServers;
    }

    private void keys(DrawContext g) {
        for (int i = 0; i < 4; i++) {
            int y = ct + 8 + i * 48;
            card(g, cx, y, cw, 40, null);
            Gfx.text(g, KEY_NAMES[i], cx + 14, y + 16, 1f, 1f, Gfx.WHITE);
            int kx = cx + cw - 152, ky = y + 8;
            boolean hv = hover(kx, ky, 140, 24), ls = listening == i;
            if (ls) Gfx.rrectH(g, kx, ky, 140, 24, 2, 1f);
            else {
                g.fill(kx, ky, kx + 140, ky + 24, Gfx.argb(Gfx.lerp(Gfx.BTN, Gfx.BTN_HI, hv ? 1f : 0f), 1f));
                Gfx.outline(g, kx, ky, 140, 24, Gfx.argb(hv ? Gfx.accent() : Gfx.LINE, 1f));
            }
            String label = ls ? "Press a key..." : Keys.name(getKey(i));
            centered(g, label, kx + 70, ky + 8, 1f, 1f, ls ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) {
                listening = i;
                for (int k = 32; k <= 348; k++) if (Keys.valid(k)) prev[k] = Keys.down(win, k);
            }
        }
    }

    private void loading(DrawContext g) {
        Config c = Config.I;
        int yA = ct + 14, yB = ct + 14 + 46, yC = ct + 14 + 92;

        boolean h1 = card(g, cx, yA, lw, 38, null);
        Gfx.text(g, "Custom loading screens", cx + 12, yA + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, yA + 12, c.themeLoading, "tl");
        if (h1 && pressed) c.themeLoading = !c.themeLoading;

        boolean h2 = card(g, rx, yA, lw, 38, null);
        Gfx.text(g, "Show tips", rx + 12, yA + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, rx + lw - 40, yA + 12, c.loadTips, "lt");
        if (h2 && pressed) c.loadTips = !c.loadTips;

        card(g, cx, yB, lw, 38, "Loading title");
        card(g, rx, yB, lw, 38, "Loading message");

        card(g, cx, yC, lw, 38, null);
        Gfx.text(g, "Style", cx + 12, yC + 15, 1f, 1f, Gfx.WHITE);
        for (int i = 0; i < 3; i++) {
            int x = cx + lw - 12 - 3 * 50 - 2 * 4 + i * 54, y = yC + 9;
            boolean sel = c.loadStyle == i, hv = hover(x, y, 50, 20);
            if (sel) Gfx.rrectH(g, x, y, 50, 20, 2, 1f);
            else g.fill(x, y, x + 50, y + 20, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
            centered(g, LOAD_STYLES[i], x + 25, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) c.loadStyle = i;
        }
        card(g, rx, yC, lw, 38, null);
        if (button(g, "Preview loading screen", rx + 8, yC + 7, lw - 16, 24, true)) {
            act(() -> client.setScreen(new PobyLoadingPreviewScreen(this)));
        }
    }
}
