package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PobyMenuScreen extends PobyScreen {
    static int tab = 0, preset = 0;
    static final int PW = 560, PH = 330;
    static final String[] KEY_NAMES = {"Open Menu", "HUD Editor", "Toggle Sprint", "Full Bright"};
    static final String[] LOAD_STYLES = {"Bar", "Dots", "Pulse"};

    private final Screen parent;
    private int listening = -1, px, py, cx, cw;
    private boolean menuHeld, dragSlider;
    private final boolean[] prev = new boolean[350];
    private TextFieldWidget hexA, hexB, titleField, subField;

    public PobyMenuScreen() { this(null); }

    public PobyMenuScreen(Screen parent) {
        super(Text.literal("Poby Client"));
        this.parent = parent;
        menuHeld = Keys.down(MinecraftClient.getInstance().getWindow().getHandle(), Config.I.keyMenu);
    }

    private int getKey(int i) {
        Config c = Config.I;
        return switch (i) { case 0 -> c.keyMenu; case 1 -> c.keyEditor; case 2 -> c.keySprint; default -> c.keyBright; };
    }

    private void setKey(int i, int v) {
        Config c = Config.I;
        switch (i) {
            case 0 -> c.keyMenu = v;
            case 1 -> c.keyEditor = v;
            case 2 -> c.keySprint = v;
            default -> c.keyBright = v;
        }
    }

    private static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    private static int parse(String s) {
        try {
            s = s.trim();
            if (s.startsWith("#")) s = s.substring(1);
            return s.length() == 6 ? Integer.parseInt(s, 16) : -1;
        } catch (Exception e) { return -1; }
    }

    private static String abbr(String id) {
        return switch (id) {
            case "fps" -> "FPS"; case "clock" -> "CLK"; case "directions" -> "DIR"; case "memory" -> "MEM";
            case "customtext" -> "TXT"; case "cps" -> "CPS"; case "ping" -> "MS"; case "coords" -> "XYZ";
            case "togglesprint" -> "SPR"; case "fullbright" -> "BRT"; case "fpsboost" -> "FPS+";
            case "armor" -> "ARM"; default -> "KEY";
        };
    }

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
        cx = px + 20;
        cw = PW - 40;
    }

    private TextFieldWidget field(int x, int y, int w, String placeholder) {
        return new TextFieldWidget(textRenderer, (int) (x * s), (int) (y * s), (int) (w * s), Math.max(14, (int) (16 * s)), Text.literal(placeholder));
    }

    private void rebuild() { clearChildren(); init(); }

    @Override
    protected void init() {
        layout();
        int rx = cx + 264;
        if (tab == 1) {
            hexA = field(rx + 10, py + 124, 112, "Start");
            hexA.setMaxLength(7);
            hexA.setText(hex(Config.I.colorA));
            hexA.setChangedListener(v -> { int c = parse(v); if (c >= 0) { Config.I.colorA = c; preset = -1; } });
            hexB = field(rx + 134, py + 124, 112, "End");
            hexB.setMaxLength(7);
            hexB.setText(hex(Config.I.colorB));
            hexB.setChangedListener(v -> { int c = parse(v); if (c >= 0) { Config.I.colorB = c; preset = -1; } });
            addDrawableChild(hexA);
            addDrawableChild(hexB);
        } else if (tab == 3) {
            titleField = field(cx + 10, py + 130, 236, "Title");
            titleField.setMaxLength(24);
            titleField.setText(Config.I.loadTitle);
            titleField.setChangedListener(v -> Config.I.loadTitle = v);
            subField = field(rx + 10, py + 130, 236, "Message");
            subField.setMaxLength(40);
            subField.setText(Config.I.loadSub);
            subField.setChangedListener(v -> Config.I.loadSub = v);
            addDrawableChild(titleField);
            addDrawableChild(subField);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return listening < 0; }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }

    @Override
    protected void onFrame() {
        boolean menuNow = Keys.down(win, Config.I.keyMenu);
        if (listening >= 0) {
            for (int k = 32; k <= 348; k++) {
                if (!Keys.valid(k)) continue;
                boolean d = Keys.down(win, k);
                if (d && !prev[k]) {
                    if (k != GLFW.GLFW_KEY_ESCAPE) setKey(listening, k == GLFW.GLFW_KEY_DELETE ? -1 : k);
                    listening = -1;
                    break;
                }
                prev[k] = d;
            }
        } else if (menuNow && !menuHeld && !(getFocused() instanceof TextFieldWidget tf && tf.isFocused())) {
            act(this::close);
        }
        menuHeld = Keys.down(win, Config.I.keyMenu);
        if (!down) dragSlider = false;
    }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.glass(g, px, py, PW, PH, 16, 0.80f, 0f);
        Gfx.hGradient(g, px + 18, py + 1, PW - 36, 1, 0.9f);
    }

    @Override
    protected void paintFront(DrawContext g) {
        Gfx.text(g, "POBY", px + 20, py + 19, 1.7f, 1f, -1);
        int pillW = 4 * 66 + 8, tx = px + (PW - pillW) / 2;
        Gfx.rrect(g, tx, py + 14, pillW, 26, 13, Gfx.argb(0xFFFFFF, 0.10f));
        String[] tn = {"Modules", "Preferences", "Keybinds", "Loading"};
        for (int i = 0; i < 4; i++) {
            int x = tx + 4 + i * 66, y = py + 17;
            boolean sel = tab == i, hv = hover(x, y, 66, 20);
            if (sel) Gfx.rrectH(g, x, y, 66, 20, 10, 1f);
            else if (hv) Gfx.rrect(g, x, y, 66, 20, 10, Gfx.argb(0xFFFFFF, 0.10f));
            centered(g, tn[i], x + 33, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv && !sel) {
                final int idx = i;
                act(() -> { tab = idx; listening = -1; rebuild(); });
            }
        }
        if (button(g, "HUD Editor", px + PW - 138, py + 14, 84, 26, false)) act(() -> client.setScreen(new HudEditorScreen(this)));
        if (iconButton(g, "x", px + PW - 46, py + 14, 26)) act(this::close);

        if (tab == 0) modules(g);
        else if (tab == 1) prefs(g);
        else if (tab == 2) keys(g);
        else loading(g);

        Gfx.text(g, Keys.name(Config.I.keyMenu) + " to close", cx, py + PH - 18, 1f, 0.7f, Gfx.MUTED);
    }

    private void modules(DrawContext g) {
        Gfx.text(g, Hud.MODS.size() + " modules  -  click a tile to enable it", cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        int w = (cw - 24) / 4, h = 52, i = 0;
        for (Hud.Mod m : Hud.MODS) {
            int x = cx + (i % 4) * (w + 8), y = py + 66 + (i / 4) * 58;
            boolean hv = hover(x, y, w, h), on = m.on(), custom = m.id.equals("customtext");
            float k = ease("t" + m.id, hv, 14f);
            if (on) {
                Gfx.rrectH(g, x - 1, y - 1, w + 2, h + 2, 12, 1f);
                Gfx.rrect(g, x, y, w, h, 11, Gfx.argb(Gfx.BASE, 0.93f));
                Gfx.rrect(g, x, y, w, h, 11, Gfx.argb(0xFFFFFF, 0.04f * k));
            } else {
                Gfx.glass(g, x, y, w, h, 12, 0.35f, 0.05f * k);
            }
            if (on) Gfx.rrectH(g, x + 10, y + 8, 28, 28, 14, 1f);
            else Gfx.rrect(g, x + 10, y + 8, 28, 28, 14, Gfx.argb(0xFFFFFF, 0.12f));
            String ab = abbr(m.id);
            Gfx.text(g, ab, x + 24 - Gfx.width(ab) * 0.75f / 2f, y + 19, 0.75f, 1f, on ? Gfx.BASE : Gfx.WHITE);
            toggle(g, x + w - 38, y + 11, on, "m" + m.id);
            Gfx.text(g, m.name, x + 10, y + 33, 1f, 1f, Gfx.WHITE);
            String status = custom ? Config.I.texts.size() + " texts - edit" : (on ? "Enabled" : "Disabled");
            Gfx.text(g, status, x + 10, y + 43, 0.8f, 1f, custom || on ? (Config.I.colorB & 0xFFFFFF) : Gfx.MUTED);
            if (pressed && hv) {
                if (custom && mx < x + w - 44) act(() -> client.setScreen(new PobyCustomTextScreen(this)));
                else m.set(!on);
            }
            i++;
        }
    }

    private boolean card(DrawContext g, int x, int y, int w, int h, String label) {
        boolean hv = hover(x, y, w, h);
        Gfx.glass(g, x, y, w, h, 10, 0.35f, hv ? 0.04f : 0f);
        if (label != null) Gfx.text(g, label, x + 10, y + 5, 0.9f, 1f, Gfx.MUTED);
        return hv;
    }

    private void prefs(DrawContext g) {
        Config c = Config.I;
        String tname = preset >= 0 && preset < Gfx.PRESETS.length ? Gfx.PRESETS[preset].name() : "Custom";
        Gfx.text(g, "Theme: " + tname, cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        int n = Gfx.PRESETS.length, per = 7, chw = (cw - (per - 1) * 8) / per;
        for (int i = 0; i < n; i++) {
            Gfx.Preset p = Gfx.PRESETS[i];
            int x = cx + (i % per) * (chw + 8), y = py + 64 + (i / per) * 20;
            boolean hv = hover(x, y, chw, 16);
            if (preset == i) Gfx.rrect(g, x - 2, y - 2, chw + 4, 20, 10, 0xFFFFFFFF);
            else if (hv) Gfx.rrect(g, x - 1, y - 1, chw + 2, 18, 9, 0x99FFFFFF);
            Gfx.rrectGrad(g, x, y, chw, 16, 8, p.a(), p.b(), 1f);
            if (pressed && hv) {
                c.colorA = p.a();
                c.colorB = p.b();
                hexA.setText(hex(p.a()));
                hexB.setText(hex(p.b()));
                preset = i;
            }
        }
        int y1 = py + 108, y2 = py + 152, y3 = py + 196, y4 = py + 240, lw = 256, rx = cx + 264;

        boolean h1 = card(g, cx, y1, lw, 38, null);
        Gfx.text(g, "Gradient Text", cx + 12, y1 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y1 + 12, c.gradientText, "gt");
        if (h1 && pressed) c.gradientText = !c.gradientText;

        boolean h2 = card(g, cx, y2, lw, 38, null);
        Gfx.text(g, "Animations", cx + 12, y2 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y2 + 12, c.animations, "an");
        if (h2 && pressed) c.animations = !c.animations;

        card(g, cx, y3, lw, 38, null);
        Gfx.text(g, "Font", cx + 12, y3 + 15, 1f, 1f, Gfx.WHITE);
        String[] fn = {"Smooth", "Bold"};
        for (int i = 0; i < 2; i++) {
            int x = cx + lw - 138 + i * 64, y = y3 + 9;
            boolean sel = c.boldFont == (i == 1), hv = hover(x, y, 62, 20);
            if (sel) Gfx.rrectH(g, x, y, 62, 20, 10, 1f);
            else Gfx.rrect(g, x, y, 62, 20, 10, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
            centered(g, fn[i], x + 31, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) c.boldFont = i == 1;
        }

        boolean h4 = card(g, cx, y4, lw, 38, null);
        Gfx.text(g, "Theme Minecraft menus", cx + 12, y4 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, y4 + 12, c.themeMenus, "tm");
        if (h4 && pressed) c.themeMenus = !c.themeMenus;

        // right column
        card(g, rx, y1, lw, 38, "Gradient colors (hex)");

        card(g, rx, y2, lw, 38, null);
        Gfx.text(g, "Speed", rx + 12, y2 + 15, 1f, 1f, Gfx.WHITE);
        int sx = rx + 62, sw = 130, sy = y2;
        float v = Math.max(0f, Math.min(1f, (c.animSpeed - 0.25f) / 2.75f));
        if (pressed && hover(sx - 6, sy, sw + 12, 38)) dragSlider = true;
        if (dragSlider) {
            v = Math.max(0f, Math.min(1f, (mx - sx) / (float) sw));
            c.animSpeed = 0.25f + v * 2.75f;
        }
        Gfx.rrect(g, sx, sy + 17, sw, 4, 2, Gfx.argb(0xFFFFFF, 0.18f));
        Gfx.rrectH(g, sx, sy + 17, Math.max(4, (int) (sw * v)), 4, 2, 1f);
        Gfx.rrect(g, sx + (int) (sw * v) - 6, sy + 13, 12, 12, 6, 0xFFFFFFFF);
        Gfx.text(g, String.format("%.2fx", c.animSpeed), sx + sw + 10, sy + 15, 1f, 1f, Gfx.WHITE);

        boolean h3 = card(g, rx, y3, lw, 38, null);
        Gfx.text(g, "Menus on servers", rx + 12, y3 + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, rx + lw - 40, y3 + 12, c.themeOnServers, "ts");
        if (h3 && pressed) c.themeOnServers = !c.themeOnServers;
    }

    private void keys(DrawContext g) {
        Gfx.text(g, "Click a key, then press the new one.  ESC cancels, DEL unbinds.", cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        for (int i = 0; i < 4; i++) {
            int y = py + 66 + i * 48;
            card(g, cx, y, cw, 40, null);
            Gfx.text(g, KEY_NAMES[i], cx + 14, y + 16, 1f, 1f, Gfx.WHITE);
            int kx = cx + cw - 152, ky = y + 8;
            boolean hv = hover(kx, ky, 140, 24), ls = listening == i;
            if (ls) Gfx.rrectH(g, kx, ky, 140, 24, 12, 1f);
            else {
                Gfx.rrect(g, kx, ky, 140, 24, 12, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
                Gfx.rrectStroke(g, kx, ky, 140, 24, 12, Gfx.argb(0xFFFFFF, 0.25f));
            }
            String label = ls ? "Press a key..." : Keys.name(getKey(i));
            centered(g, label, kx + 70, ky + 8, 1f, 1f, ls ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) {
                listening = i;
                for (int k = 32; k <= 348; k++) if (Keys.valid(k)) prev[k] = Keys.down(win, k);
            }
        }
    }

    private void loading(DrawContext g) {
        Config c = Config.I;
        Gfx.text(g, "Applies to the startup screen, loading terrain and world loading.", cx, py + 52, 1f, 0.9f, Gfx.MUTED);
        int lw = 256, rx = cx + 264, yA = py + 68, yB = py + 114, yC = py + 160;

        boolean h1 = card(g, cx, yA, lw, 38, null);
        Gfx.text(g, "Custom loading screens", cx + 12, yA + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, cx + lw - 40, yA + 12, c.themeLoading, "tl");
        if (h1 && pressed) c.themeLoading = !c.themeLoading;

        boolean h2 = card(g, rx, yA, lw, 38, null);
        Gfx.text(g, "Show tips", rx + 12, yA + 15, 1f, 1f, Gfx.WHITE);
        toggle(g, rx + lw - 40, yA + 12, c.loadTips, "lt");
        if (h2 && pressed) c.loadTips = !c.loadTips;

        card(g, cx, yB, lw, 38, "Loading title");
        card(g, rx, yB, lw, 38, "Loading message");

        card(g, cx, yC, lw, 38, null);
        Gfx.text(g, "Style", cx + 12, yC + 15, 1f, 1f, Gfx.WHITE);
        for (int i = 0; i < 3; i++) {
            int x = cx + lw - 12 - 194 + i * 66, y = yC + 9;
            boolean sel = c.loadStyle == i, hv = hover(x, y, 62, 20);
            if (sel) Gfx.rrectH(g, x, y, 62, 20, 10, 1f);
            else Gfx.rrect(g, x, y, 62, 20, 10, Gfx.argb(0xFFFFFF, hv ? 0.18f : 0.10f));
            centered(g, LOAD_STYLES[i], x + 31, y + 6, 1f, 1f, sel ? Gfx.BASE : Gfx.WHITE);
            if (pressed && hv) c.loadStyle = i;
        }
        card(g, rx, yC, lw, 38, null);
        if (button(g, "Preview loading screen", rx + 12, yC + 6, lw - 24, 26, true)) {
            act(() -> client.setScreen(new PobyLoadingPreviewScreen(this)));
        }
    }
}
