package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

public class PobyTitleScreen extends PobyScreen {
    private final long start = System.currentTimeMillis();

    public PobyTitleScreen() { super(Text.literal("Poby Client")); }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    protected void paintBack(DrawContext g) { Gfx.backdrop(g, dw, dh); }

    @Override
    protected void paintFront(DrawContext g) {
        float t = (System.currentTimeMillis() - start) / 1000f;
        float fade = Config.I.animations ? Math.min(1f, t / (0.9f / Config.I.animSpeed)) : 1f;
        float bob = Config.I.animations ? (float) Math.sin(t * 1.5f * Config.I.animSpeed) * 2f : 0f;
        int cx = dw / 2, cy = dh / 2;

        centered(g, "POBY", cx, (int) (cy - 118 + bob), 5.5f, fade, -1);
        centered(g, "C  L  I  E  N  T", cx, (int) (cy - 64 + bob), 1.4f, fade * 0.9f, -1);

        int bw = 210, x = cx - bw / 2, y = cy - 34;
        Gfx.glass(g, x - 14, y - 12, bw + 28, 168, 18, 0.55f, 0f);
        if (button(g, "Singleplayer", x, y, bw, 28, false)) act(() -> client.setScreen(new PobySingleplayerScreen(this)));
        if (button(g, "Multiplayer", x, y + 34, bw, 28, false)) act(() -> client.setScreen(new PobyMultiplayerScreen(this)));
        if (button(g, "Poby Menu", x, y + 68, bw, 28, true)) act(() -> client.setScreen(new PobyMenuScreen(this)));
        if (button(g, "Options", x, y + 102, bw / 2 - 3, 28, false)) act(() -> client.setScreen(new OptionsScreen(this, client.options)));
        if (button(g, "Quit", x + bw / 2 + 3, y + 102, bw / 2 - 3, 28, false)) act(() -> client.scheduleStop());

        Gfx.text(g, "Poby Client v1.4.0", 8, dh - 14, 1f, 0.7f, Gfx.MUTED);
        String hint = Keys.name(Config.I.keyMenu) + " opens the menu in game";
        Gfx.text(g, hint, dw - Gfx.width(hint) - 8, dh - 14, 1f, 0.7f, Gfx.MUTED);
    }
}
