package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

public class PobyTitleScreen extends PobyScreen {
    private final long start = System.currentTimeMillis();

    public PobyTitleScreen() { super(Text.literal("Poby Client")); }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    protected void paintBack(DrawContext g) { Gfx.backdrop(g, dw, dh); }

    @Override
    protected void paintFront(DrawContext g) {
        float t = (System.currentTimeMillis() - start) / 1000f;
        float fade = Config.I.animations ? Math.min(1f, t / (0.7f / Config.I.animSpeed)) : 1f;
        int acc = Gfx.accent();

        int pw = Math.max(210, Math.min(280, (int) (dw * 0.30f)));
        int px0 = dw - pw;
        g.fill(px0, 0, dw, dh, Gfx.argb(Gfx.PANEL, 0.97f));
        g.fill(px0 - 2, 0, px0, dh, Gfx.argb(acc, fade));
        int cx = px0 + pw / 2;

        int bh = 24, gap = 8, total = 32 + 10 + 9 + 24 + 4 * (bh + gap) + bh;
        int top = Math.max(10, (dh - total) / 2);
        Gfx.spaced(g, "POBY", cx, top, 4f, 8f, fade, Gfx.WHITE);
        Gfx.spaced(g, "CLIENT", cx, top + 42, 1f, 6f, fade * 0.9f, Gfx.MUTED);

        int bw = pw - 44, x = px0 + 22, y = top + 75;
        if (button(g, "Singleplayer", x, y, bw, bh, false)) act(() -> client.setScreen(new PobySingleplayerScreen(this)));
        y += bh + gap;
        if (button(g, "Multiplayer", x, y, bw, bh, false)) act(() -> client.setScreen(new PobyMultiplayerScreen(this)));
        y += bh + gap;
        if (button(g, "Poby Menu", x, y, bw, bh, true)) act(() -> client.setScreen(new PobyMenuScreen(this)));
        y += bh + gap;
        if (button(g, "Options", x, y, bw, bh, false)) act(() -> client.setScreen(new OptionsScreen(this, client.options)));
        y += bh + gap;
        if (button(g, "Quit", x, y, bw, bh, false)) act(() -> client.scheduleStop());

        Gfx.text(g, "Poby Client v1.6.0", 8, dh - 14, 1f, 0.7f, Gfx.MUTED);
        String hint = Keys.name(Config.I.keyMenu) + " opens the menu in game";
        Gfx.text(g, hint, cx - Gfx.width(hint) * 0.85f / 2f, dh - 14, 0.85f, 0.7f, Gfx.MUTED);
    }
}
