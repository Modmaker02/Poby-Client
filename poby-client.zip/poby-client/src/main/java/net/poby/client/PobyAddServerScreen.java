package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import net.minecraft.text.Text;

public class PobyAddServerScreen extends PobyScreen {
    private final Screen parent;
    private final ServerList list;
    private TextFieldWidget name, addr;
    private int px, py;
    static final int PW = 340, PH = 190;

    public PobyAddServerScreen(Screen parent, ServerList list) {
        super(Text.literal("Add Server"));
        this.parent = parent;
        this.list = list;
    }

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
    }

    private TextFieldWidget field(int x, int y, int w, String ph) {
        return new TextFieldWidget(textRenderer, (int) (x * s), (int) (y * s), (int) (w * s), Math.max(14, (int) (18 * s)), Text.literal(ph));
    }

    @Override
    protected void init() {
        layout();
        name = field(px + 20, py + 56, PW - 40, "Server name");
        name.setMaxLength(32);
        name.setText("Minecraft Server");
        addr = field(px + 20, py + 106, PW - 40, "Server address");
        addr.setMaxLength(128);
        addDrawableChild(name);
        addDrawableChild(addr);
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.window(g, px, py, PW, PH);
    }

    @Override
    protected void paintFront(DrawContext g) {
        Gfx.text(g, "Add Server", px + 20, py + 16, 1.5f, 1f, -1);
        Gfx.text(g, "Name", px + 20, py + 44, 0.9f, 1f, Gfx.MUTED);
        Gfx.text(g, "Address  (e.g. play.example.com)", px + 20, py + 94, 0.9f, 1f, Gfx.MUTED);
        if (button(g, "Add Server", px + 20, py + PH - 40, 140, 26, true)) {
            String a = addr.getText().trim();
            if (!a.isEmpty()) {
                String n = name.getText().trim();
                list.add(new ServerInfo(n.isEmpty() ? "Minecraft Server" : n, a, ServerInfo.ServerType.OTHER), false);
                list.saveFile();
                act(this::close);
            }
        }
        if (button(g, "Cancel", px + PW - 20 - 100, py + PH - 40, 100, 26, false)) act(this::close);
    }
}
