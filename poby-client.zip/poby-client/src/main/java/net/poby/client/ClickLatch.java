package net.poby.client;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWMouseButtonCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallbackI;

/**
 * Remembers left-clicks straight from GLFW so a quick tap (press + release inside one frame, common on touch /
 * launcher setups) is never missed by the polled Poby screens.
 */
public final class ClickLatch {
    private ClickLatch() {}

    private static final long MAX_AGE_NS = 250_000_000L;
    private static volatile boolean pending;
    private static volatile long pressNs;
    private static long installedFor;

    public static void install(long window) {
        if (window == 0L || installedFor == window) return;
        try {
            final GLFWMouseButtonCallbackI[] prev = new GLFWMouseButtonCallbackI[1];
            GLFWMouseButtonCallbackI mine = (w, button, action, mods) -> {
                if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && action == GLFW.GLFW_PRESS) {
                    pending = true;
                    pressNs = System.nanoTime();
                }
                if (prev[0] != null) prev[0].invoke(w, button, action, mods);
            };
            GLFWMouseButtonCallback old = GLFW.glfwSetMouseButtonCallback(window, mine);
            prev[0] = old;
            installedFor = window;
        } catch (Throwable t) {
            Log.error("clicklatch", t);
        }
    }

    public static void clear() { pending = false; }

    /** True once per fresh click. */
    public static boolean take() {
        boolean p = pending;
        pending = false;
        return p && System.nanoTime() - pressNs < MAX_AGE_NS;
    }
}
