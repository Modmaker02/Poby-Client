package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;

import java.util.*;

/** Hides duplicate entities stacked in the same block (armor stands, minecarts) so only one is rendered. */
public final class FpsBoost {
    private FpsBoost() {}

    public static volatile Set<Integer> hidden = Collections.emptySet();
    private static int counter;

    private static final Set<EntityType<?>> TYPES = Set.of(
        EntityType.ARMOR_STAND, EntityType.CHEST_MINECART, EntityType.HOPPER_MINECART,
        EntityType.TNT_MINECART, EntityType.MINECART, EntityType.FURNACE_MINECART);

    private record Key(EntityType<?> type, long pos) {}

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || !Hud.get("fpsboost").on()) {
            if (!hidden.isEmpty()) hidden = Collections.emptySet();
            return;
        }
        if (++counter % 4 != 0) return;
        Map<Key, List<Entity>> groups = new HashMap<>();
        for (Entity e : mc.world.getEntities()) {
            if (!TYPES.contains(e.getType())) continue;
            groups.computeIfAbsent(new Key(e.getType(), e.getBlockPos().asLong()), k -> new ArrayList<>()).add(e);
        }
        Set<Integer> out = new HashSet<>();
        for (List<Entity> l : groups.values()) {
            if (l.size() < Math.max(2, Config.I.stackMin)) continue;
            int keep = Integer.MAX_VALUE;
            for (Entity e : l) keep = Math.min(keep, e.getId());
            for (Entity e : l) if (e.getId() != keep) out.add(e.getId());
        }
        hidden = out;
    }
}
