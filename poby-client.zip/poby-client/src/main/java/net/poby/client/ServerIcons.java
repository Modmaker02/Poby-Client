package net.poby.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;

import javax.imageio.ImageIO;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Real server icons for the Poby server list. Uses the icon saved in servers.dat when there is one, otherwise
 * pings the server once in the background (plain Minecraft status ping) and reads its favicon. Drawn with fills,
 * so it needs no texture APIs. If anything fails the caller just draws the letter badge.
 */
public final class ServerIcons {
    private ServerIcons() {}

    static final int SIZE = 32;
    private static final int[] NONE = new int[0];

    /** What we know about one server (filled in by the background ping). */
    public static final class Info {
        public volatile int[] px = null;
        public volatile int online = -1, max = -1;
        public volatile long ms = -1;
        public volatile boolean done = false;
    }

    private static final Map<String, Info> CACHE = new ConcurrentHashMap<>();
    private static final Map<String, int[]> ICONS = new ConcurrentHashMap<>();

    /** Info for a server; starts the background ping the first time it is asked for. */
    public static Info info(ServerInfo si) {
        Info in = CACHE.get(si.address);
        if (in == null) {
            in = new Info();
            CACHE.put(si.address, in);
            start(si, in);
        }
        return in;
    }

    public static void forget(String address) { CACHE.remove(address); }

    /** Draws a 32x32 pixel array at x,y. Returns false if there is nothing to draw. */
    public static boolean drawPixels(DrawContext g, int[] px, int x, int y) {
        try {
            if (px == null || px.length != SIZE * SIZE) return false;
            for (int j = 0; j < SIZE; j++) {
                int i = 0;
                while (i < SIZE) {
                    int c = px[j * SIZE + i], k = i + 1;
                    while (k < SIZE && px[j * SIZE + k] == c) k++;
                    if ((c >>> 24) != 0) g.fill(x + i, y + j, x + k, y + j + 1, c);
                    i = k;
                }
            }
            Gfx.outline(g, x, y, SIZE, SIZE, Gfx.argb(Gfx.LINE, 0.8f));
            return true;
        } catch (Throwable t) {
            Log.error("servericon.draw", t);
            return false;
        }
    }

    /** Server icon (the server's own favicon). */
    public static boolean draw(DrawContext g, ServerInfo si, int x, int y) {
        return drawPixels(g, info(si).px, x, y);
    }

    /** Any other icon loaded once in the background (world icons). Loader returns PNG bytes or null. */
    public static boolean drawAsync(DrawContext g, String key, int x, int y, java.util.concurrent.Callable<byte[]> loader) {
        int[] px = ICONS.get(key);
        if (px == null) {
            ICONS.put(key, NONE);
            Thread th = new Thread(() -> {
                try {
                    byte[] b = loader.call();
                    int[] p = b == null ? null : scale(b);
                    ICONS.put(key, p == null ? NONE : p);
                } catch (Throwable t) {
                    ICONS.put(key, NONE);
                }
            }, "poby-icon");
            th.setDaemon(true);
            th.start();
            return false;
        }
        return drawPixels(g, px, x, y);
    }

    private static void start(ServerInfo si, Info in) {
        final String addr = si.address;
        final byte[] saved = savedIcon(si);
        if (saved != null) {
            try { in.px = scale(saved); } catch (Throwable ignored) { }
        }
        Thread th = new Thread(() -> {
            try {
                ping(addr, in);
            } catch (Throwable t) {
                // offline or no reply: keep whatever we already have
            } finally {
                in.done = true;
            }
        }, "poby-server-ping");
        th.setDaemon(true);
        th.start();
    }

    /** The icon vanilla already saved for this server (found by return type, so it survives renames). */
    private static byte[] savedIcon(ServerInfo si) {
        try {
            for (Method m : ServerInfo.class.getMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == byte[].class) {
                    Object o = m.invoke(si);
                    if (o instanceof byte[] b && b.length > 0) return b;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static int[] scale(byte[] png) throws IOException {
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(png));
        if (img == null) return null;
        int w = img.getWidth(), h = img.getHeight();
        int[] out = new int[SIZE * SIZE];
        for (int j = 0; j < SIZE; j++) {
            for (int i = 0; i < SIZE; i++) {
                int x0 = i * w / SIZE, x1 = Math.max(x0 + 1, (i + 1) * w / SIZE);
                int y0 = j * h / SIZE, y1 = Math.max(y0 + 1, (j + 1) * h / SIZE);
                long a = 0, r = 0, gr = 0, b = 0;
                int n = 0;
                for (int yy = y0; yy < y1 && yy < h; yy++) {
                    for (int xx = x0; xx < x1 && xx < w; xx++) {
                        int c = img.getRGB(xx, yy);
                        a += c >>> 24; r += (c >> 16) & 255; gr += (c >> 8) & 255; b += c & 255;
                        n++;
                    }
                }
                if (n == 0) n = 1;
                out[j * SIZE + i] = ((int) (a / n) << 24) | ((int) (r / n) << 16) | ((int) (gr / n) << 8) | (int) (b / n);
            }
        }
        return out;
    }

    // ------------------------------------------------------------ minimal status ping
    private static void ping(String address, Info info) throws Exception {
        String host = address.trim();
        int port = 25565;
        boolean explicit = false;
        int colon = host.lastIndexOf(':');
        if (colon > 0 && host.indexOf(':') == colon) {
            try {
                port = Integer.parseInt(host.substring(colon + 1));
                host = host.substring(0, colon);
                explicit = true;
            } catch (NumberFormatException ignored) {
            }
        }
        String target = host;
        if (!explicit) {
            try {
                Hashtable<String, String> env = new Hashtable<>();
                env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
                env.put("java.naming.provider.url", "dns:");
                env.put("com.sun.jndi.dns.timeout.initial", "3000");
                env.put("com.sun.jndi.dns.timeout.retries", "1");
                DirContext ctx = new InitialDirContext(env);
                Attribute a = ctx.getAttributes("_minecraft._tcp." + host, new String[]{"SRV"}).get("srv");
                if (a != null && a.size() > 0) {
                    String[] p = a.get(0).toString().split(" ");
                    port = Integer.parseInt(p[2]);
                    target = p[3].endsWith(".") ? p[3].substring(0, p[3].length() - 1) : p[3];
                }
            } catch (Throwable ignored) {
            }
        }
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(target, port), 4000);
            s.setSoTimeout(4000);
            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            DataInputStream in = new DataInputStream(s.getInputStream());
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            DataOutputStream h = new DataOutputStream(hb);
            writeVarInt(h, 0);
            writeVarInt(h, 767);
            byte[] hn = host.getBytes(StandardCharsets.UTF_8);
            writeVarInt(h, hn.length);
            h.write(hn);
            h.writeShort(port);
            writeVarInt(h, 1);
            long t0 = System.currentTimeMillis();
            writeVarInt(out, hb.size());
            out.write(hb.toByteArray());
            writeVarInt(out, 1);
            writeVarInt(out, 0);
            out.flush();
            readVarInt(in);
            readVarInt(in);
            int len = readVarInt(in);
            info.ms = System.currentTimeMillis() - t0;
            if (len <= 0 || len > (1 << 21)) return;
            byte[] data = new byte[len];
            in.readFully(data);
            JsonObject o = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            try {
                JsonObject pl = o.getAsJsonObject("players");
                info.online = pl.get("online").getAsInt();
                info.max = pl.get("max").getAsInt();
            } catch (Throwable ignored) {
            }
            if (o.has("favicon")) {
                String f = o.get("favicon").getAsString();
                int comma = f.indexOf(',');
                if (comma >= 0) f = f.substring(comma + 1);
                int[] px = scale(Base64.getMimeDecoder().decode(f));
                if (px != null) info.px = px;
            }
        }
    }

    private static void writeVarInt(DataOutputStream o, int v) throws IOException {
        while ((v & ~0x7F) != 0) {
            o.writeByte((v & 0x7F) | 0x80);
            v >>>= 7;
        }
        o.writeByte(v);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int v = 0, pos = 0;
        while (true) {
            int b = in.readUnsignedByte();
            v |= (b & 0x7F) << pos;
            if ((b & 0x80) == 0) return v;
            pos += 7;
            if (pos >= 35) throw new IOException("VarInt too big");
        }
    }
}
