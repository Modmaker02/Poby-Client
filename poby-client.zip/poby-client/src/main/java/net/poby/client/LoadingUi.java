package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

/** The Poby loading screen: used for the Mojang startup screen, "Loading terrain" and world loading. */
public final class LoadingUi {
    private LoadingUi() {}

    private static boolean splashBroken, overlayBroken;

    static final String[] TIPS = {
        "Press Right Shift to open the Poby menu",
        "Drag your HUD around in the HUD Editor",
        "FPS Boost renders stacked armor stands and minecarts as one",
        "Add as many Custom Texts as you want",
        "Change the whole theme in Preferences"
    };

    public static boolean isLoadingScreen(Screen s) {
        return !(s instanceof PobyScreen) && s.children().isEmpty() && !s.shouldCloseOnEsc();
    }

    public static void draw(DrawContext g, int w, int h, String sub) {
        Config c = Config.I;
        float t = (System.currentTimeMillis() % 1000000L) / 1000f;
        Gfx.backdrop(g, w, h);
        int cx = w / 2, cy = h / 2;

        String title = c.loadTitle == null || c.loadTitle.isBlank() ? "POBY CLIENT" : c.loadTitle;
        float sc = 4.5f;
        while (sc > 1.2f && Gfx.width(title) * sc > w - 40) sc -= 0.5f;
        int th = (int) (9 * sc);
        Gfx.text(g, title, cx - Gfx.width(title) * sc / 2f, cy - th - 22, sc, 1f, -1);
        if (sub != null && !sub.isBlank()) {
            Gfx.text(g, sub, cx - Gfx.width(sub) / 2f, cy - 12, 1f, 0.85f, Gfx.MUTED);
        }

        if (c.loadStyle == 1) {
            for (int i = 0; i < 5; i++) {
                float k = (float) Math.sin(t * 4f + i * 0.7f);
                int dy = (int) (k * 4);
                Gfx.rrect(g, cx - 40 + i * 18, cy + 10 + dy, 8, 8, 4, Gfx.argb(Gfx.grad(i / 5f), 0.55f + 0.45f * (k * 0.5f + 0.5f)));
            }
        } else if (c.loadStyle == 2) {
            float p = (t * 0.8f) % 1f;
            int r = (int) (6 + p * 22);
            Gfx.rrect(g, cx - r, cy + 14 - r, r * 2, r * 2, r, Gfx.argb(Gfx.grad(p), (1f - p) * 0.55f));
            Gfx.rrectH(g, cx - 4, cy + 10, 8, 8, 4, 1f);
        } else {
            int tw = 180;
            Gfx.rrect(g, cx - tw / 2, cy + 11, tw, 6, 3, Gfx.argb(0xFFFFFF, 0.12f));
            float p = (t * 0.7f) % 1f;
            int seg = 70, start = (int) ((tw + seg) * p) - seg;
            int s0 = Math.max(0, start), e0 = Math.min(tw, start + seg);
            if (e0 - s0 > 3) Gfx.rrectH(g, cx - tw / 2 + s0, cy + 11, e0 - s0, 6, 3, 1f);
        }

        if (c.loadTips) {
            String tip = TIPS[((int) (t / 4f)) % TIPS.length];
            Gfx.text(g, tip, cx - Gfx.width(tip) / 2f, h - 28, 1f, 0.8f, Gfx.MUTED);
        }
    }

    /** Mojang startup screen (drawn on top of the vanilla logo). */
    public static void splash(DrawContext g) {
        if (splashBroken || !Config.I.themeLoading) return;
        try {
            draw(g, g.getScaledWindowWidth(), g.getScaledWindowHeight(), Config.I.loadSub);
        } catch (Throwable t) {
            splashBroken = true;
            Log.error("loading.splash", t);
        }
    }

    /** "Loading terrain", world loading and similar screens. */
    public static void overlay(DrawContext g, Screen s) {
        if (overlayBroken || !Config.I.themeLoading) return;
        try {
            String sub = s.getTitle().getString();
            if (sub == null || sub.isBlank()) sub = Config.I.loadSub;
            draw(g, g.getScaledWindowWidth(), g.getScaledWindowHeight(), sub);
        } catch (Throwable t) {
            overlayBroken = true;
            Log.error("loading.overlay", t);
        }
    }
}
