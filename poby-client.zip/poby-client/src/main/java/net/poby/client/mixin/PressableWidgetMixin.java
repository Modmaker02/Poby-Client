package net.poby.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import net.poby.client.PobyTheme;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    @Inject(method = "renderWidget(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void poby$render(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        ClickableWidget w = (ClickableWidget) (Object) this;
        if (PobyTheme.buttonStyled(w) && PobyTheme.button(context, w)) ci.cancel();
    }
}
