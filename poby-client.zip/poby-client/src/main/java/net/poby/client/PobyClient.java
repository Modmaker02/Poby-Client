package net.poby.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;

public class PobyClient implements ClientModInitializer {
    public static boolean titleBroken;
    private static boolean hudBroken, tickBroken;
    private boolean dMenu, dEditor, dSprint, dBright, brightApplied;

    @Override
    public void onInitializeClient() {
        Config.load();
        Hud.init();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            try {
                if (LoadingUi.isLoadingScreen(screen)) {
                    ScreenEvents.afterRender(screen).register((sc, ctx, mouseX, mouseY, tickDelta) -> LoadingUi.overlay(ctx, sc));
                }
            } catch (Throwable t) {
                Log.error("loading.hook", t);
            }
        });
        HudRenderCallback.EVENT.register((g, tickCounter) -> {
            if (hudBroken) return;
            try {
                var mc = MinecraftClient.getInstance();
                Hud.pollCps();
                if (mc.player == null || mc.options.hudHidden) return;
                if (mc.currentScreen instanceof HudEditorScreen) return;
                Hud.renderAll(g, false);
            } catch (Throwable t) {
                hudBroken = true;
                Log.error("hud", t);
            }
        });
    }

    private void toggle(MinecraftClient mc, String id, String label) {
        Hud.Mod m = Hud.get(id);
        m.set(!m.on());
        if (mc.player != null) mc.player.sendMessage(Text.literal(label + ": " + (m.on() ? "ON" : "OFF")), true);
    }

    private void tick(MinecraftClient mc) {
        if (tickBroken) return;
        try {
            tickSafe(mc);
        } catch (Throwable t) {
            tickBroken = true;
            Log.error("tick", t);
        }
    }

    private void tickSafe(MinecraftClient mc) {
        if (!titleBroken && mc.currentScreen instanceof TitleScreen) {
            mc.setScreen(new PobyTitleScreen());
            return;
        }

        FpsBoost.tick(mc);
        Boost.tick(mc);

        long win = mc.getWindow().getHandle();
        Config c = Config.I;
        boolean m = Keys.down(win, c.keyMenu), e = Keys.down(win, c.keyEditor);
        boolean s = Keys.down(win, c.keySprint), b = Keys.down(win, c.keyBright);

        if (mc.currentScreen == null && mc.player != null) {
            if (m && !dMenu) mc.setScreen(new PobyMenuScreen());
            else if (e && !dEditor) mc.setScreen(new HudEditorScreen(null));
            if (s && !dSprint) toggle(mc, "togglesprint", "Toggle Sprint");
            if (b && !dBright) toggle(mc, "fullbright", "Full Bright");
        }
        dMenu = m; dEditor = e; dSprint = s; dBright = b;

        var p = mc.player;
        if (p == null) { brightApplied = false; return; }

        if (Hud.get("togglesprint").on() && mc.currentScreen == null && mc.options.forwardKey.isPressed()
            && !p.isSneaking() && !p.isUsingItem() && !p.horizontalCollision
            && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying)) {
            p.setSprinting(true);
        }

        if (Hud.get("fullbright").on()) {
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,
                    StatusEffectInstance.INFINITE, 0, false, false, false));
                brightApplied = true;
            }
        } else if (brightApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            brightApplied = false;
        }
    }
}
