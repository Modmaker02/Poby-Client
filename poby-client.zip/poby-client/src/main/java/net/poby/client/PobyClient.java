package net.poby.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;

public class PobyClient implements ClientModInitializer {
    private boolean dMenu, dEditor, dSprint, dBright, brightApplied;

    @Override
    public void onInitializeClient() {
        Config.load();
        Hud.init();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register((g, tickCounter) -> {
            var mc = MinecraftClient.getInstance();
            Hud.pollCps();
            if (mc.player == null || mc.options.hudHidden) return;
            if (mc.currentScreen instanceof HudEditorScreen) return;
            Hud.renderAll(g, false);
        });
    }

    private void toggle(MinecraftClient mc, String id, String label) {
        Hud.Mod m = Hud.get(id);
        m.set(!m.on());
        if (mc.player != null) mc.player.sendMessage(Text.literal(label + ": " + (m.on() ? "ON" : "OFF")), true);
    }

    private void tick(MinecraftClient mc) {
        // Custom Poby home screen replaces the vanilla title screen
        if (mc.currentScreen instanceof TitleScreen) {
            mc.setScreen(new PobyTitleScreen());
            return;
        }

        long win = mc.getWindow().getHandle();
        Config c = Config.I;
        boolean m = Keys.down(win, c.keyMenu), e = Keys.down(win, c.keyEditor);
        boolean s = Keys.down(win, c.keySprint), b = Keys.down(win, c.keyBright);

        if (mc.currentScreen == null && mc.player != null) {
            if (m && !dMenu) mc.setScreen(new PobyMenuScreen());
            else if (e && !dEditor) mc.setScreen(new HudEditorScreen(null));
            if (s && !dSprint) toggle(mc, "togglesprint", "Toggle Sprint");
            if (b && !dBright) toggle(mc, "fullbright", "Full Bright");
        }
        dMenu = m; dEditor = e; dSprint = s; dBright = b;

        var p = mc.player;
        if (p == null) { brightApplied = false; return; }

        // Toggle sprint
        if (Hud.get("togglesprint").on() && mc.currentScreen == null && mc.options.forwardKey.isPressed()
            && !p.isSneaking() && !p.isUsingItem() && !p.horizontalCollision
            && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying)) {
            p.setSprinting(true);
        }

        // Full bright (client-side infinite night vision, no particles / icon)
        if (Hud.get("fullbright").on()) {
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,
                    StatusEffectInstance.INFINITE, 0, false, false, false));
                brightApplied = true;
            }
        } else if (brightApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            brightApplied = false;
        }
    }
}
