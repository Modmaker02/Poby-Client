package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends PobyScreen {
    private final Screen parent;
    private Hud.Mod drag;
    private int offX, offY;
    private boolean editorHeld;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
        editorHeld = Keys.down(MinecraftClient.getInstance().getWindow().getHandle(), Config.I.keyEditor);
    }

    @Override
    protected float uiScale() { return 1f; }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }

    @Override
    protected void onFrame() {
        boolean eNow = Keys.down(win, Config.I.keyEditor);
        if (eNow && !editorHeld) act(this::close);
        editorHeld = eNow;

        if (pressed && my < height - 52) {
            java.util.List<Hud.Mod> all = Hud.all();
            for (int i = all.size() - 1; i >= 0; i--) {
                Hud.Mod m = all.get(i);
                if (m.hud && m.on() && hover(m.rx, m.ry, m.w, m.h)) {
                    drag = m; offX = mx - m.rx; offY = my - m.ry;
                    break;
                }
            }
        }
        if (down && drag != null) {
            drag.move(Math.max(0, Math.min(mx - offX, width - drag.w)), Math.max(0, Math.min(my - offY, height - drag.h)));
        }
        if (!down && drag != null) { drag = null; Config.save(); }
    }

    @Override
    protected void paintBack(DrawContext g) {
        g.fill(0, 0, width, height, 0x66000000);
        Hud.renderAll(g, true);
        for (Hud.Mod m : Hud.all()) {
            if (!m.hud || !m.on()) continue;
            boolean hv = hover(m.rx, m.ry, m.w, m.h);
            int col = drag == m ? 0xFFFFFFFF : Gfx.argb(Gfx.grad(0.5f), hv ? 1f : 0.55f);
            Gfx.outline(g, m.rx - 2, m.ry - 2, m.w + 4, m.h + 4, col);
            if (hv || drag == m) g.drawText(textRenderer, m.name, m.rx, Math.max(2, m.ry - 12), 0xFFFFFFFF, true);
        }
    }

    @Override
    protected void paintFront(DrawContext g) {
        String info = "HUD Editor  -  drag elements to move them";
        int iw = Gfx.width(info) + 28;
        Gfx.glass(g, (width - iw) / 2, 8, iw, 22, 11, 0.85f, 0f);
        Gfx.text(g, info, (width - Gfx.width(info)) / 2f, 15, 1f, 1f, Gfx.WHITE);
        if (Hud.all().stream().noneMatch(m -> m.hud && m.on())) {
            String none = "No HUD modules enabled - turn some on in the Poby Menu";
            Gfx.text(g, none, (width - Gfx.width(none)) / 2f, height / 2f, 1f, 1f, Gfx.WHITE);
        }
        int bx = width / 2 - 120, by = height - 44;
        Gfx.glass(g, bx, by, 240, 34, 17, 0.85f, 0f);
        if (button(g, "Reset", bx + 6, by + 4, 108, 26, false)) { Config.I.pos.clear(); Config.save(); }
        if (button(g, "Done", bx + 126, by + 4, 108, 26, true)) act(this::close);
    }
}
