package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Matrix3x2fStack;

public final class Gfx {
    private Gfx() {}

    public record Preset(String name, int a, int b) {}

    public static final Preset[] PRESETS = {
        new Preset("Frost", 0x00C8FF, 0x00FFAA),
        new Preset("Sunset", 0xFF3D81, 0xFFB347),
        new Preset("Ocean", 0x2193B0, 0x6DD5ED),
        new Preset("Grape", 0x8B5CFF, 0xFF6AD5),
        new Preset("Lime", 0x84FF3B, 0x00D68F),
        new Preset("Fire", 0xF12711, 0xF5AF19),
        new Preset("Mono", 0xFFFFFF, 0x8A8A8A)
    };

    public static final int WHITE = 0xF2F8FF, MUTED = 0x8FA3C0, BASE = 0x08101C;

    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    public static int lerp(int a, int b, float t) {
        t = clamp(t);
        int r = (int) ((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * t);
        int g = (int) ((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static float phase() {
        return Config.I.animations ? (System.currentTimeMillis() % 200000L) / 1000f * 0.2f * Config.I.animSpeed : 0f;
    }

    public static int grad(float t) {
        float p = (t + phase()) % 2f;
        if (p > 1f) p = 2f - p;
        return lerp(Config.I.colorA, Config.I.colorB, p);
    }

    public static int argb(int rgb, float a) {
        return (((int) (clamp(a) * 255)) << 24) | (rgb & 0xFFFFFF);
    }

    static Text styled(String s) {
        var t = Text.literal(s);
        return Config.I.boldFont ? t.formatted(Formatting.BOLD) : t;
    }

    public static int width(String s) { return mc().textRenderer.getWidth(styled(s)); }

    public static void text(DrawContext g, String s, float x, float y, float a) {
        text(g, s, x, y, 1f, a, -1);
    }

    /** solid >= 0 -> that RGB colour, otherwise gradient (or white if gradient text is off). */
    public static void text(DrawContext g, String s, float x, float y, float scale, float a, int solid) {
        TextRenderer f = mc().textRenderer;
        boolean bold = Config.I.boldFont;
        int total = Math.max(1, f.getWidth(styled(s)));
        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        if (!bold) {
            float o = 0.7f / scale;
            m.pushMatrix();
            m.translate(o, o);
            g.drawText(f, styled(s), 0, 0, argb(0x000000, a * 0.45f), false);
            m.popMatrix();
        }
        float cx = 0;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            Text t = styled(new String(Character.toChars(cp)));
            int col = solid >= 0 ? argb(solid, a)
                : Config.I.gradientText ? argb(grad(cx / total), a) : argb(0xFFFFFF, a);
            m.pushMatrix();
            m.translate(cx, 0);
            g.drawText(f, t, 0, 0, col, bold);
            m.popMatrix();
            cx += f.getWidth(t);
        }
        m.popMatrix();
    }

    // ------------------------------------------------------------ rounded shapes
    private static int inset(int r, int i) {
        double dy = r - (i + 0.5);
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    public static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Rounded rect filled with the theme gradient (animated). */
    public static void rrectH(DrawContext g, int x, int y, int w, int h, int r, float a) {
        rrectCols(g, x, y, w, h, r, -1, -1, a);
    }

    /** Rounded rect filled with a fixed two-colour gradient. */
    public static void rrectGrad(DrawContext g, int x, int y, int w, int h, int r, int ca, int cb, float a) {
        rrectCols(g, x, y, w, h, r, ca, cb, a);
    }

    private static void rrectCols(DrawContext g, int x, int y, int w, int h, int r, int ca, int cb, float a) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < w; i++) {
            int in = 0;
            if (i < r) in = inset(r, i);
            else if (i >= w - r) in = inset(r, w - 1 - i);
            float t = i / (float) Math.max(1, w - 1);
            int col = argb(ca < 0 ? grad(t) : lerp(ca, cb, t), a);
            g.fill(x + i, y + in, x + i + 1, y + h - in, col);
        }
    }

    public static void outline(DrawContext g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    public static void hGradient(DrawContext g, int x, int y, int w, int h, float a) {
        for (int i = 0; i < w; i += 2) {
            g.fill(x + i, y, x + Math.min(i + 2, w), y + h, argb(grad(i / (float) w), a));
        }
    }

    /** HUD element background: dark glass pill with a gradient underline. */
    public static void panel(DrawContext g, int x, int y, int w, int h, float a) {
        rrect(g, x, y, w, h, 3, argb(BASE, a * 0.72f));
        for (int i = 4; i < w - 4; i += 2) {
            g.fill(x + i, y + h - 2, x + Math.min(i + 2, w - 4), y + h - 1, argb(grad(i / (float) w), a));
        }
    }

    public static void rrectStroke(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x + r, y, x + w - r, y + 1, c);
        g.fill(x + r, y + h - 1, x + w - r, y + h, c);
        g.fill(x, y + r, x + 1, y + h - r, c);
        g.fill(x + w - 1, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            int end = i == 0 ? r : Math.max(inset(r, i - 1), in + 1);
            if (end <= in) end = in + 1;
            g.fill(x + in, y + i, x + end, y + i + 1, c);
            g.fill(x + w - end, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + end, y + h - i, c);
            g.fill(x + w - end, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    /** Frosted glass card. */
    public static void glass(DrawContext g, int x, int y, int w, int h, int r, float navyA, float lift) {
        rrect(g, x, y, w, h, r, argb(BASE, navyA));
        rrect(g, x, y, w, h, r, argb(0xFFFFFF, 0.06f + lift));
        rrectStroke(g, x, y, w, h, r, argb(0xFFFFFF, 0.20f + lift));
    }

    public static void glow(DrawContext g, int cx, int cy, int radius, int rgb, float a) {
        for (int k = 0; k < 6; k++) {
            int rad = radius * (6 - k) / 6;
            rrect(g, cx - rad, cy - rad, rad * 2, rad * 2, rad, argb(rgb, a));
        }
    }

    public static void backdrop(DrawContext g, int w, int h) {
        float t = Config.I.animations ? (System.currentTimeMillis() % 1000000L) / 1000f * Config.I.animSpeed : 0f;
        g.fillGradient(0, 0, w, h, argb(lerp(0x050A14, grad(0f), 0.20f), 1f), argb(lerp(0x050A14, grad(1f), 0.20f), 1f));
        glow(g, (int) (w * 0.22f + Math.sin(t * 0.3f) * 30), (int) (h * 0.3f), 90, grad(0.1f), 0.04f);
        glow(g, (int) (w * 0.80f + Math.cos(t * 0.25f) * 30), (int) (h * 0.75f), 110, grad(0.9f), 0.035f);
        for (int i = 0; i < 45; i++) {
            float x = ((i * 97 % w) + t * (4 + i % 5 * 3)) % w;
            float y = h - ((i * 53 % h) + t * (6 + i % 7 * 4)) % h;
            int sz = 1 + i % 3;
            float al = 0.12f + 0.2f * (float) Math.sin(t * 0.8f + i);
            g.fill((int) x, (int) y, (int) x + sz, (int) y + sz, argb(grad(i / 45f), Math.abs(al)));
        }
    }
}
