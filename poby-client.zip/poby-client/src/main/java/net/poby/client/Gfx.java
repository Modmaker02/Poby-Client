package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Matrix3x2fStack;

public final class Gfx {
    private Gfx() {}

    public record Preset(String name, int a, int b) {}

    public static final Preset[] PRESETS = {
        new Preset("Frost", 0x2FA8FF, 0xBFE6FF),
        new Preset("Sky", 0x4DA3FF, 0xFFFFFF),
        new Preset("Ocean", 0x1F7AE0, 0x9CCBFF),
        new Preset("Royal", 0x1E5BFF, 0x8FB8FF),
        new Preset("Aurora", 0x00E5A8, 0x4D8DFF),
        new Preset("Mint", 0x00D68F, 0xC9FFEA),
        new Preset("Lime", 0x84FF3B, 0x00D68F),
        new Preset("Sunset", 0xFF3D81, 0xFFB347),
        new Preset("Rose", 0xFF6AA8, 0xFFD6E6),
        new Preset("Grape", 0x8B5CFF, 0xFF6AD5),
        new Preset("Gold", 0xFFB300, 0xFFF0B3),
        new Preset("Fire", 0xF12711, 0xF5AF19),
        new Preset("Cyber", 0x00F0FF, 0xFF2BD6),
        new Preset("Mono", 0xFFFFFF, 0x8A8A8A)
    };

    public static final int WHITE = 0xF2F8FF, MUTED = 0x8FA3C0, BASE = 0x08101C;
    /** Frost palette: dark side panel, window surface, button fill / hover, outline, and the night scene. */
    public static final int PANEL = 0x050D1A, SURFACE = 0x0A1830, BTN = 0x0C2442, BTN_HI = 0x14396A, LINE = 0x2B5C94;
    static final int SKY_TOP = 0x0B1D38, SKY_BOT = 0x060E1C, MOUNT_FAR = 0x15354D, MOUNT_NEAR = 0x0E2438;

    /** Main accent colour (first theme colour). */
    public static int accent() { return Config.I.colorA & 0xFFFFFF; }

    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    public static int lerp(int a, int b, float t) {
        t = clamp(t);
        int r = (int) ((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * t);
        int g = (int) ((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static float phase() {
        return Config.I.animations ? (System.currentTimeMillis() % 200000L) / 1000f * 0.2f * Config.I.animSpeed : 0f;
    }

    public static int grad(float t) {
        float p = (t + phase()) % 2f;
        if (p > 1f) p = 2f - p;
        return lerp(Config.I.colorA, Config.I.colorB, p);
    }

    public static int argb(int rgb, float a) {
        return (((int) (clamp(a) * 255)) << 24) | (rgb & 0xFFFFFF);
    }

    static Text styled(String s) {
        var t = Text.literal(s);
        return Config.I.boldFont ? t.formatted(Formatting.BOLD) : t;
    }

    public static int width(String s) { return mc().textRenderer.getWidth(styled(s)); }

    public static void text(DrawContext g, String s, float x, float y, float a) {
        text(g, s, x, y, 1f, a, -1);
    }

    /** solid >= 0 -> that RGB colour, otherwise gradient (or white if gradient text is off). */
    public static void text(DrawContext g, String s, float x, float y, float scale, float a, int solid) {
        TextRenderer f = mc().textRenderer;
        boolean bold = Config.I.boldFont;
        int total = Math.max(1, f.getWidth(styled(s)));
        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        try {
            m.translate(x, y);
            m.scale(scale, scale);
            if (!bold) {
                float o = 0.7f / scale;
                m.pushMatrix();
                try {
                    m.translate(o, o);
                    g.drawText(f, styled(s), 0, 0, argb(0x000000, a * 0.45f), false);
                } finally {
                    m.popMatrix();
                }
            }
            float cx = 0;
            for (int i = 0; i < s.length(); ) {
                int cp = s.codePointAt(i);
                i += Character.charCount(cp);
                Text t = styled(new String(Character.toChars(cp)));
                int col = solid >= 0 ? argb(solid, a)
                    : Config.I.gradientText ? argb(grad(cx / total), a) : argb(0xFFFFFF, a);
                m.pushMatrix();
                try {
                    m.translate(cx, 0);
                    g.drawText(f, t, 0, 0, col, bold);
                } finally {
                    m.popMatrix();
                }
                cx += f.getWidth(t);
            }
        } finally {
            m.popMatrix();
        }
    }

    // ------------------------------------------------------------ rounded shapes
    private static int inset(int r, int i) {
        double dy = r - (i + 0.5);
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    /** Frost look: corners are only slightly rounded. */
    private static int cap(int r) { return Math.min(r, 2); }

    public static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = cap(Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Rounded rect filled with the theme gradient (animated). */
    public static void rrectH(DrawContext g, int x, int y, int w, int h, int r, float a) {
        rrectCols(g, x, y, w, h, r, -1, -1, a);
    }

    /** Rounded rect filled with a fixed two-colour gradient. */
    public static void rrectGrad(DrawContext g, int x, int y, int w, int h, int r, int ca, int cb, float a) {
        rrectCols(g, x, y, w, h, r, ca, cb, a);
    }

    private static void rrectCols(DrawContext g, int x, int y, int w, int h, int r, int ca, int cb, float a) {
        r = cap(Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < w; ) {
            int in = 0, step = 1;
            if (i < r) in = inset(r, i);
            else if (i >= w - r) in = inset(r, w - 1 - i);
            else step = Math.min(2, w - r - i);
            float t = i / (float) Math.max(1, w - 1);
            int col = argb(ca < 0 ? grad(t) : lerp(ca, cb, t), a);
            g.fill(x + i, y + in, x + i + step, y + h - in, col);
            i += step;
        }
    }

    public static void outline(DrawContext g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    public static void hGradient(DrawContext g, int x, int y, int w, int h, float a) {
        for (int i = 0; i < w; i += 2) {
            g.fill(x + i, y, x + Math.min(i + 2, w), y + h, argb(grad(i / (float) w), a));
        }
    }

    /** HUD element background: dark navy box with a thin outline and an accent bar on the left. */
    public static void panel(DrawContext g, int x, int y, int w, int h, float a) {
        g.fill(x, y, x + w, y + h, argb(PANEL, a * 0.80f));
        outline(g, x, y, w, h, argb(LINE, a * 0.55f));
        g.fill(x, y, x + 2, y + h, argb(grad(0.5f), a));
    }

    public static void rrectStroke(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = cap(Math.min(r, Math.min(w, h) / 2));
        g.fill(x + r, y, x + w - r, y + 1, c);
        g.fill(x + r, y + h - 1, x + w - r, y + h, c);
        g.fill(x, y + r, x + 1, y + h - r, c);
        g.fill(x + w - 1, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            int end = i == 0 ? r : Math.max(inset(r, i - 1), in + 1);
            if (end <= in) end = in + 1;
            g.fill(x + in, y + i, x + end, y + i + 1, c);
            g.fill(x + w - end, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + end, y + h - i, c);
            g.fill(x + w - end, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    /** Dark navy card with a thin blue outline (cards, tiles, rows). */
    public static void glass(DrawContext g, int x, int y, int w, int h, int r, float navyA, float lift) {
        g.fill(x, y, x + w, y + h, argb(BTN, clamp(navyA + 0.25f)));
        if (lift > 0f) g.fill(x, y, x + w, y + h, argb(0xFFFFFF, lift));
        outline(g, x, y, w, h, argb(LINE, clamp(0.45f + lift * 4f)));
    }

    /** Main window: surface colour, thin outline and an animated accent bar on top. */
    public static void window(DrawContext g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, argb(SURFACE, 0.97f));
        outline(g, x, y, w, h, argb(LINE, 0.75f));
        hGradient(g, x, y, w, 2, 1f);
    }

    /** Animated accent bar. */
    public static void accentBar(DrawContext g, int x, int y, int w) {
        hGradient(g, x, y, w, 2, 1f);
    }

    public static float spacedWidth(String s, float scale, float gap) {
        float total = 0f;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            total += width(new String(Character.toChars(cp))) * scale + gap;
        }
        return Math.max(0f, total - gap);
    }

    /** Letter-spaced text centred on cx (the "AEON  CLIENT" look). */
    public static void spaced(DrawContext g, String s, float cx, float y, float scale, float gap, float a, int solid) {
        float x = cx - spacedWidth(s, scale, gap) / 2f;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            String ch = new String(Character.toChars(cp));
            text(g, ch, x, y, scale, a, solid);
            x += width(ch) * scale + gap;
        }
    }

    public static void glow(DrawContext g, int cx, int cy, int radius, int rgb, float a) {
        for (int k = 0; k < 4; k++) {
            int rad = radius * (4 - k) / 4;
            rrect(g, cx - rad, cy - rad, rad * 2, rad * 2, rad, argb(rgb, a));
        }
    }

    private static final float[] FAR = {
        0f, 0.64f, 0.10f, 0.54f, 0.19f, 0.60f, 0.31f, 0.40f, 0.44f, 0.58f,
        0.58f, 0.50f, 0.72f, 0.62f, 0.86f, 0.48f, 1f, 0.60f};
    private static final float[] NEAR = {
        0f, 0.82f, 0.13f, 0.72f, 0.27f, 0.80f, 0.41f, 0.74f, 0.57f, 0.84f,
        0.71f, 0.76f, 0.86f, 0.82f, 1f, 0.74f};

    private static float ridge(float[] p, float x) {
        for (int i = 0; i + 3 < p.length; i += 2) {
            if (x <= p[i + 2]) {
                float t = (x - p[i]) / Math.max(0.0001f, p[i + 2] - p[i]);
                return p[i + 1] + (p[i + 3] - p[i + 1]) * t;
            }
        }
        return p[p.length - 1];
    }

    /** Frost scene: night sky, stars and two mountain ridges. */
    public static void backdrop(DrawContext g, int w, int h) {
        float t = Config.I.animations ? (System.currentTimeMillis() % 1000000L) / 1000f * Config.I.animSpeed : 0f;
        g.fillGradient(0, 0, w, h, argb(SKY_TOP, 1f), argb(SKY_BOT, 1f));
        int sh = Math.max(1, (int) (h * 0.62f)), sw = Math.max(1, w);
        for (int i = 0; i < 80; i++) {
            long hs = (i + 1) * 2654435761L;
            int sx = (int) ((hs >>> 4) % sw);
            int sy = (int) ((hs >>> 24) % sh);
            int sz = i % 9 == 0 ? 2 : 1;
            float al = 0.25f + 0.55f * (0.5f + 0.5f * (float) Math.sin(t * 1.3f + i * 1.7f));
            g.fill(sx, sy, sx + sz, sy + sz, argb(0xFFFFFF, al));
        }
        int st = w > 900 ? 3 : 2;
        for (int x = 0; x < w; x += st) {
            int top = (int) (ridge(FAR, x / (float) w) * h);
            g.fill(x, top, Math.min(w, x + st), h, argb(MOUNT_FAR, 1f));
        }
        for (int x = 0; x < w; x += st) {
            int top = (int) (ridge(NEAR, x / (float) w) * h);
            g.fill(x, top, Math.min(w, x + st), h, argb(MOUNT_NEAR, 1f));
        }
        g.fillGradient(0, (int) (h * 0.55f), w, h, 0x00000000, 0x99030812);
    }
}
