package net.poby.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

/** Writes GUI errors to config/poby-client-error.log instead of crashing the game. */
public final class Log {
    private Log() {}

    public static void error(String where, Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            Files.writeString(FabricLoader.getInstance().getConfigDir().resolve("poby-client-error.log"),
                "[" + java.time.LocalDateTime.now() + "] " + where + "\n" + sw + "\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
        }
        t.printStackTrace();
    }
}
