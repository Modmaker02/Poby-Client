package net.poby.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.poby.client.PobyTheme;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void poby$background(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        Screen self = (Screen) (Object) this;
        if (PobyTheme.screenActive(self) && PobyTheme.background(context)) ci.cancel();
    }
}
