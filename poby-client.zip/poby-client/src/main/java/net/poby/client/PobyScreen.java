package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Base for all Poby screens: custom-drawn "Frost" UI in a scaled design space, mouse polled via GLFW. */
public abstract class PobyScreen extends Screen {
    protected int mx, my, dw, dh;
    protected float s = 1f;
    protected boolean down, pressed, prevDown;
    protected long win;
    protected float dt;
    private long lastNs = System.nanoTime();
    private Runnable pending;
    private final Map<String, Float> anim = new HashMap<>();

    protected PobyScreen(Text title) {
        super(title);
        long w = MinecraftClient.getInstance().getWindow().getHandle();
        prevDown = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    protected abstract void paintBack(DrawContext g);

    protected abstract void paintFront(DrawContext g);

    protected void onFrame() {}

    protected void onScroll(int dir) {}

    protected float uiScale() { return Math.min(1f, Math.min(width / 580f, height / 350f)); }

    protected void computeScale() {
        s = Math.max(0.4f, uiScale());
        dw = (int) (width / s);
        dh = (int) (height / s);
    }

    protected void act(Runnable r) { pending = r; }

    @Override
    public void renderBackground(DrawContext g, int a, int b, float c) {}

    @Override
    public boolean mouseScrolled(double x, double y, double h, double v) {
        onScroll(v > 0 ? -1 : 1);
        return true;
    }

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        computeScale();
        win = client.getWindow().getHandle();
        mx = (int) (mouseX / s);
        my = (int) (mouseY / s);
        down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pressed = down && !prevDown;
        prevDown = down;
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        onFrame();
        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        m.scale(s, s);
        paintBack(g);
        m.popMatrix();
        super.render(g, mouseX, mouseY, delta);
        m.pushMatrix();
        m.scale(s, s);
        paintFront(g);
        m.popMatrix();
        if (pending != null) {
            Runnable r = pending;
            pending = null;
            r.run();
        }
    }

    protected boolean hover(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    protected float ease(String key, boolean on, float speed) {
        float t = on ? 1f : 0f;
        float v = anim.getOrDefault(key, t);
        v = Config.I.animations ? v + (t - v) * Math.min(1f, dt * speed * Config.I.animSpeed) : t;
        anim.put(key, v);
        return v;
    }

    /** Frost pill button. */
    protected boolean button(DrawContext g, String label, int x, int y, int w, int h, boolean primary) {
        boolean hv = hover(x, y, w, h);
        float k = ease("btn" + x + "," + y, hv, 14f);
        int r = h / 2;
        if (primary) {
            Gfx.rrectH(g, x, y, w, h, r, 0.85f + 0.15f * k);
        } else {
            Gfx.rrect(g, x, y, w, h, r, Gfx.argb(0xFFFFFF, 0.08f + 0.10f * k));
            Gfx.rrectStroke(g, x, y, w, h, r, Gfx.argb(0xFFFFFF, 0.22f + 0.25f * k));
        }
        float tw = Gfx.width(label);
        Gfx.text(g, label, x + (w - tw) / 2f, y + (h - 8) / 2f, 1f, 1f, primary ? Gfx.BASE : Gfx.WHITE);
        return pressed && hv;
    }

    /** Round glass icon button. */
    protected boolean iconButton(DrawContext g, String label, int x, int y, int size) {
        return button(g, label, x, y, size, size, false);
    }

    protected void toggle(DrawContext g, int x, int y, boolean on, String key) {
        float k = ease(key, on, 16f);
        Gfx.rrect(g, x, y, 28, 14, 7, Gfx.argb(0xFFFFFF, 0.16f));
        if (k > 0.03f) Gfx.rrectH(g, x, y, 28, 14, 7, k);
        Gfx.rrect(g, x + 2 + (int) (14 * k), y + 2, 10, 10, 5, 0xFFFFFFFF);
    }

    protected void centered(DrawContext g, String t, int cx, int y, float scale, float a, int solid) {
        Gfx.text(g, t, cx - Gfx.width(t) * scale / 2f, y, scale, a, solid);
    }
}
