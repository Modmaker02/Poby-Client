package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Base for all Poby screens: custom-drawn "Frost" UI in a scaled design space, mouse polled via GLFW. */
public abstract class PobyScreen extends Screen {
    protected int mx, my, dw, dh;
    protected float s = 1f;
    protected boolean down, pressed, prevDown;
    protected long win;
    protected float dt;
    private long lastNs = System.nanoTime();
    private Runnable pending;
    private final Map<String, Float> anim = new HashMap<>();

    protected PobyScreen(Text title) {
        super(title);
        long w = MinecraftClient.getInstance().getWindow().getHandle();
        prevDown = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    protected abstract void paintBack(DrawContext g);

    protected abstract void paintFront(DrawContext g);

    protected void onFrame() {}

    protected void onScroll(int dir) {}

    protected float uiScale() { return Math.min(1f, Math.min(width / 580f, height / 350f)); }

    protected void computeScale() {
        s = Math.max(0.4f, uiScale());
        dw = (int) (width / s);
        dh = (int) (height / s);
    }

    protected void act(Runnable r) { pending = r; }

    @Override
    public void renderBackground(DrawContext g, int a, int b, float c) {}

    @Override
    public boolean mouseScrolled(double x, double y, double h, double v) {
        onScroll(v > 0 ? -1 : 1);
        return true;
    }

    private boolean failed;

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        if (failed) return;
        try {
            renderSafe(g, mouseX, mouseY, delta);
        } catch (Throwable t) {
            failed = true;
            Log.error(getClass().getSimpleName() + ".render", t);
            final MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                if (this instanceof PobyTitleScreen) {
                    PobyClient.titleBroken = true;
                    mc.setScreen(new TitleScreen());
                } else {
                    mc.setScreen(null);
                }
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal("Poby GUI error - see config/poby-client-error.log"), false);
                }
            });
        }
    }

    private void renderSafe(DrawContext g, int mouseX, int mouseY, float delta) {
        computeScale();
        win = client.getWindow().getHandle();
        mx = (int) (mouseX / s);
        my = (int) (mouseY / s);
        down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        pressed = down && !prevDown;
        prevDown = down;
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        onFrame();
        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        try {
            m.scale(s, s);
            paintBack(g);
        } finally {
            m.popMatrix();
        }
        super.render(g, mouseX, mouseY, delta);
        m.pushMatrix();
        try {
            m.scale(s, s);
            paintFront(g);
        } finally {
            m.popMatrix();
        }
        if (pending != null) {
            Runnable r = pending;
            pending = null;
            r.run();
        }
    }

    protected boolean hover(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    protected float ease(String key, boolean on, float speed) {
        float t = on ? 1f : 0f;
        float v = anim.getOrDefault(key, t);
        v = Config.I.animations ? v + (t - v) * Math.min(1f, dt * speed * Config.I.animSpeed) : t;
        anim.put(key, v);
        return v;
    }

    /** Frost button: square navy fill, blue outline, accent border on hover. */
    protected boolean button(DrawContext g, String label, int x, int y, int w, int h, boolean primary) {
        boolean hv = hover(x, y, w, h);
        float k = ease("btn" + x + "," + y, hv, 14f);
        int acc = Gfx.accent();
        if (primary) {
            g.fill(x, y, x + w, y + h, Gfx.argb(acc, 0.22f + 0.18f * k));
            Gfx.outline(g, x, y, w, h, Gfx.argb(acc, 0.85f + 0.15f * k));
        } else {
            g.fill(x, y, x + w, y + h, Gfx.argb(Gfx.lerp(Gfx.BTN, Gfx.BTN_HI, k), 0.95f));
            Gfx.outline(g, x, y, w, h, Gfx.argb(Gfx.lerp(Gfx.LINE, acc, k), 1f));
        }
        if (k > 0.02f) Gfx.outline(g, x + 1, y + 1, w - 2, h - 2, Gfx.argb(acc, k));
        float tw = Gfx.width(label);
        Gfx.text(g, label, x + (w - tw) / 2f, y + (h - 8) / 2f, 1f, 1f, Gfx.WHITE);
        return pressed && hv;
    }

    /** Small square icon button. */
    protected boolean iconButton(DrawContext g, String label, int x, int y, int size) {
        return button(g, label, x, y, size, size, false);
    }

    protected void toggle(DrawContext g, int x, int y, boolean on, String key) {
        float k = ease(key, on, 16f);
        int acc = Gfx.accent();
        g.fill(x, y, x + 28, y + 14, Gfx.argb(Gfx.lerp(0x16283F, acc, k), 1f));
        Gfx.outline(g, x, y, 28, 14, Gfx.argb(Gfx.lerp(Gfx.LINE, acc, k), 1f));
        int kx = x + 2 + (int) (14 * k);
        g.fill(kx, y + 2, kx + 10, y + 12, 0xFFFFFFFF);
    }

    protected void centered(DrawContext g, String t, int cx, int y, float scale, float a, int solid) {
        Gfx.text(g, t, cx - Gfx.width(t) * scale / 2f, y, scale, a, solid);
    }
}
