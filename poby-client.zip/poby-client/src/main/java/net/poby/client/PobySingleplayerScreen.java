package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.world.level.storage.LevelStorage;
import net.minecraft.world.level.storage.LevelSummary;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class PobySingleplayerScreen extends PobyListScreen {
    private List<LevelSummary> worlds;
    private CompletableFuture<List<LevelSummary>> future;

    public PobySingleplayerScreen(Screen parent) {
        super("Singleplayer", parent);
        try {
            LevelStorage storage = MinecraftClient.getInstance().getLevelStorage();
            future = storage.loadSummaries(storage.getLevelList());
        } catch (Exception e) {
            worlds = new ArrayList<>();
        }
    }

    @Override
    protected void onFrame() {
        if (worlds == null && future != null && future.isDone()) {
            try {
                worlds = new ArrayList<>(future.get());
                worlds.sort(Comparator.comparingLong(LevelSummary::getLastPlayed).reversed());
            } catch (Exception e) {
                worlds = new ArrayList<>();
            }
        }
    }

    @Override
    protected int count() { return worlds == null ? 0 : worlds.size(); }

    @Override
    protected String countLabel() { return worlds == null ? "Loading..." : worlds.size() + " worlds"; }

    @Override
    protected String emptyText() { return worlds == null ? "Loading worlds..." : "No worlds yet - create one!"; }

    private static String ago(long ms) {
        if (ms <= 0) return "Never played";
        long s = (System.currentTimeMillis() - ms) / 1000;
        if (s < 60) return "just now";
        if (s < 3600) return s / 60 + "m ago";
        if (s < 86400) return s / 3600 + "h ago";
        return s / 86400 + "d ago";
    }

    /** world icon.png, found by return type so it does not depend on a method name */
    private static Path iconPath(LevelSummary lv) {
        try {
            for (java.lang.reflect.Method m : LevelSummary.class.getMethods()) {
                if (m.getParameterCount() == 0 && Path.class.isAssignableFrom(m.getReturnType())
                    && m.getName().toLowerCase().contains("icon")) {
                    Object o = m.invoke(lv);
                    if (o instanceof Path p) return p;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    @Override
    protected void drawRow(DrawContext g, int i, int x, int y, int w, int h, boolean hv) {
        LevelSummary lv = worlds.get(i);
        String name = lv.getDisplayName();
        final Path ip = iconPath(lv);
        boolean drew = ip != null && ServerIcons.drawAsync(g, "world:" + lv.getName(), x + 8, y + 6,
            () -> Files.exists(ip) ? Files.readAllBytes(ip) : null);
        if (!drew) rowIcon(g, name, x, y);
        Gfx.text(g, name, x + 48, y + 9, 1f, 1f, Gfx.WHITE);
        String mode = lv.getGameMode().name().toLowerCase();
        mode = mode.substring(0, 1).toUpperCase() + mode.substring(1);
        String sub = mode + (lv.isHardcore() ? "  -  Hardcore" : "") + "  -  " + ago(lv.getLastPlayed());
        Gfx.text(g, sub, x + 48, y + 24, 0.85f, 1f, Gfx.MUTED);
        if (button(g, "Play", x + w - 66, y + 11, 56, 22, true)) {
            final String id = lv.getName();
            act(() -> client.createIntegratedServerLoader().start(id, () -> client.setScreen(this)));
        }
    }

    @Override
    protected void bottom(DrawContext g, int by) {
        if (button(g, "+  Create New World", px + 20, by, 170, 26, true)) {
            act(() -> CreateWorldScreen.show(client, () -> client.setScreen(this)));
        }
        if (button(g, "Back", px + PW - 20 - 90, by, 90, 26, false)) act(this::close);
    }
}
