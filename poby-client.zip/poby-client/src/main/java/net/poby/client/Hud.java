package net.poby.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Supplier;

public final class Hud {
    private Hud() {}

    public static final List<Mod> MODS = new ArrayList<>();
    private static final List<Mod> CUSTOM = new ArrayList<>();
    private static final Map<String, Mod> BY_ID = new HashMap<>();
    private static long last = System.nanoTime();

    // CPS tracking (polled every frame)
    private static boolean pl, pr;
    private static final ArrayDeque<Long> LC = new ArrayDeque<>(), RC = new ArrayDeque<>();

    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static Mod get(String id) { return BY_ID.get(id); }

    /** Built-in modules plus every Custom Text entry. */
    public static List<Mod> all() {
        List<Mod> l = new ArrayList<>(MODS.size() + CUSTOM.size());
        l.addAll(MODS);
        l.addAll(CUSTOM);
        return l;
    }

    /** Rebuild the draggable Custom Text elements from the config. */
    public static void syncCustom() {
        Map<String, Mod> old = new HashMap<>();
        for (Mod m : CUSTOM) old.put(m.id, m);
        CUSTOM.clear();
        int n = 0;
        for (Config.TextItem it : Config.I.texts) {
            Mod m = old.get("ct:" + it.id);
            if (m instanceof CustomTextMod c) {
                c.it = it;
                CUSTOM.add(c);
            } else {
                CUSTOM.add(new CustomTextMod(it, n));
            }
            n++;
        }
    }

    private static void add(Mod m) { MODS.add(m); BY_ID.put(m.id, m); }

    public static void init() {
        MODS.clear();
        BY_ID.clear();
        int y = 6;
        add(new TextMod("fps", "Show FPS", true, 6, y, () -> "FPS: " + mc().getCurrentFps())); y += 18;
        add(new TextMod("clock", "Realtime Clock", false, 6, y,
            () -> LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a")))); y += 18;
        add(new TextMod("directions", "Directions", false, 6, y, () -> {
            Direction d = mc().player.getHorizontalFacing();
            return "Facing: " + switch (d) {
                case NORTH -> "North (-Z)";
                case SOUTH -> "South (+Z)";
                case EAST -> "East (+X)";
                default -> "West (-X)";
            };
        })); y += 18;
        add(new TextMod("memory", "Memory Usage", false, 6, y, () -> {
            Runtime r = Runtime.getRuntime();
            long max = r.maxMemory() / 1048576L, used = (r.totalMemory() - r.freeMemory()) / 1048576L;
            return "Mem: " + used + "/" + max + " MB (" + (used * 100 / Math.max(1, max)) + "%)";
        })); y += 18;
        add(new FeatureMod("customtext", "Custom Text", false));
        add(new TextMod("cps", "CPS", true, 6, y, () -> "CPS: " + LC.size() + " | " + RC.size())); y += 18;
        add(new TextMod("ping", "Ping", false, 6, y, () -> {
            var nh = mc().getNetworkHandler();
            int ping = 0;
            if (nh != null) {
                var e = nh.getPlayerListEntry(mc().player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            return "Ping: " + ping + " ms";
        })); y += 18;
        add(new TextMod("coords", "Coordinates", true, 6, y, () -> {
            var p = mc().player;
            return "XYZ: " + (int) Math.floor(p.getX()) + " / " + (int) Math.floor(p.getY()) + " / " + (int) Math.floor(p.getZ());
        })); y += 18;
        add(new TextMod("togglesprint", "Toggle Sprint", false, 6, y, () -> "[Sprint: Toggled]")); y += 18;
        add(new FeatureMod("fullbright", "Full Bright", false));
        add(new FeatureMod("fpsboost", "FPS Boost", false));
        add(new ArmorMod("armor", "Armor HUD", false, -6, 6));
        add(new KeysMod("keystrokes", "Keystrokes", false, -6, 90));
        add(new StatsMod("stats", "Sidebar Stats", true, -6, 70));
        for (Mod m : MODS) Config.I.enabled.putIfAbsent(m.id, m.defOn);
        syncCustom();
    }

    public static int cpsLeft() { return LC.size(); }
    public static int cpsRight() { return RC.size(); }

    /** Call every frame: detects mouse clicks without needing mixins. */
    public static void pollCps() {
        var mc = mc();
        long win = mc.getWindow().getHandle();
        long now = System.currentTimeMillis();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.currentScreen == null) {
            if (l && !pl) LC.add(now);
            if (r && !pr) RC.add(now);
        }
        pl = l;
        pr = r;
        while (!LC.isEmpty() && now - LC.peekFirst() > 1000) LC.pollFirst();
        while (!RC.isEmpty() && now - RC.peekFirst() > 1000) RC.pollFirst();
    }

    public static void renderAll(DrawContext g, boolean editor) {
        var mc = mc();
        if (mc.player == null) return;
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        int sw = g.getScaledWindowWidth(), sh = g.getScaledWindowHeight();
        for (Mod m : all()) {
            if (!m.hud) continue;
            float target = m.on() ? 1f : 0f;
            if (!Config.I.animations || editor) m.anim = target;
            else m.anim += (target - m.anim) * Math.min(1f, dt * 10f * Config.I.animSpeed);
            if (m.anim < 0.04f) continue;
            int[] p = m.pos(sw);
            int x = Math.max(0, Math.min(p[0], sw - m.w));
            int y = Math.max(0, Math.min(p[1], sh - m.h));
            m.rx = x;
            m.ry = y;
            int slide = (Config.I.animations && !editor) ? (int) ((1f - m.anim) * -16f) : 0;
            m.draw(g, x + slide, y, m.anim, editor);
        }
    }

    // ------------------------------------------------------------------ modules

    public abstract static class Mod {
        public final String id, name;
        final boolean defOn;
        final int dx, dy;
        public int w = 80, h = 15, rx, ry;
        public boolean hud = true;
        float anim;

        Mod(String id, String name, boolean defOn, int dx, int dy) {
            this.id = id; this.name = name; this.defOn = defOn; this.dx = dx; this.dy = dy;
        }

        public boolean on() { return Config.I.enabled.getOrDefault(id, defOn); }

        public void set(boolean v) { Config.I.enabled.put(id, v); Config.save(); }

        int[] pos(int sw) {
            int[] p = Config.I.pos.get(id);
            if (p != null && p.length == 2) return p;
            return new int[]{dx < 0 ? sw + dx - w : dx, dy};
        }

        public void move(int x, int y) { Config.I.pos.put(id, new int[]{x, y}); }

        abstract void draw(DrawContext g, int x, int y, float a, boolean editor);
    }

    /** A module that only toggles a feature (no HUD panel). */
    static class FeatureMod extends Mod {
        FeatureMod(String id, String name, boolean on) {
            super(id, name, on, 0, 0);
            hud = false;
        }

        @Override
        void draw(DrawContext g, int x, int y, float a, boolean editor) {}
    }

    static final float[] SCALES = {0.8f, 1f, 1.35f, 1.8f};

    static class CustomTextMod extends Mod {
        Config.TextItem it;

        CustomTextMod(Config.TextItem it, int n) {
            super("ct:" + it.id, "Custom Text", true, 6, 130 + n * 20);
            this.it = it;
        }

        @Override
        public boolean on() { return it.enabled && get("customtext").on(); }

        @Override
        void draw(DrawContext g, int x, int y, float a, boolean editor) {
            float sc = SCALES[Math.max(0, Math.min(3, it.size))];
            String t = it.text == null || it.text.isEmpty() ? " " : it.text;
            w = (int) Math.ceil(Gfx.width(t) * sc) + 12;
            h = (int) Math.ceil(9 * sc) + 8;
            if (it.bg) Gfx.rrect(g, x, y, w, h, 3, Gfx.argb(Gfx.BASE, a * 0.72f));
            if (it.underline) {
                for (int i = 4; i < w - 4; i += 2) {
                    g.fill(x + i, y + h - 2, x + Math.min(i + 2, w - 4), y + h - 1, Gfx.argb(Gfx.grad(i / (float) w), a));
                }
            }
            int solid = it.style == 0 ? -1 : it.style == 1 ? Gfx.WHITE : (it.color & 0xFFFFFF);
            Gfx.text(g, t, x + 6, y + 4, sc, a, solid);
        }
    }

    static class TextMod extends Mod {
        final Supplier<String> s;

        TextMod(String id, String name, boolean on, int dx, int dy, Supplier<String> s) {
            super(id, name, on, dx, dy);
            this.s = s;
        }

        @Override
        void draw(DrawContext g, int x, int y, float a, boolean editor) {
            String t = s.get();
            w = Gfx.width(t) + 12;
            h = 15;
            Gfx.panel(g, x, y, w, h, a);
            Gfx.text(g, t, x + 7, y + 3.5f, a);
        }
    }

    static class ArmorMod extends Mod {
        ArmorMod(String id, String name, boolean on, int dx, int dy) {
            super(id, name, on, dx, dy);
            w = 62;
            h = 4 * 18 + 2;
        }

        @Override
        void draw(DrawContext g, int x, int y, float a, boolean editor) {
            var mc = mc();
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            Gfx.panel(g, x, y, w, h, a);
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getEquippedStack(slots[i]);
                int iy = y + 2 + i * 18;
                if (!st.isEmpty()) {
                    g.drawItem(st, x + 5, iy);
                    g.drawStackOverlay(mc.textRenderer, st, x + 5, iy);
                    if (st.isDamageable()) {
                        Gfx.text(g, String.valueOf(st.getMaxDamage() - st.getDamage()), x + 25, iy + 4, a);
                    }
                } else if (editor) {
                    Gfx.text(g, "-", x + 10, iy + 4, a);
                }
            }
        }
    }

    static class KeysMod extends Mod {
        KeysMod(String id, String name, boolean on, int dx, int dy) {
            super(id, name, on, dx, dy);
            w = 64;
            h = 3 * 22 + 12;
        }

        @Override
        void draw(DrawContext g, int x, int y, float a, boolean editor) {
            var o = mc().options;
            int s = 20, gap = 2;
            w = s * 3 + gap * 2;
            h = 3 * (s + gap) + 12;
            key(g, x + s + gap, y, s, s, "W", o.forwardKey.isPressed(), a);
            key(g, x, y + s + gap, s, s, "A", o.leftKey.isPressed(), a);
            key(g, x + s + gap, y + s + gap, s, s, "S", o.backKey.isPressed(), a);
            key(g, x + 2 * (s + gap), y + s + gap, s, s, "D", o.rightKey.isPressed(), a);
            int mw = (w - gap) / 2;
            key(g, x, y + 2 * (s + gap), mw, s, "L " + cpsLeft(), o.attackKey.isPressed(), a);
            key(g, x + mw + gap, y + 2 * (s + gap), w - mw - gap, s, "R " + cpsRight(), o.useKey.isPressed(), a);
            key(g, x, y + 3 * (s + gap), w, 10, "SPACE", o.jumpKey.isPressed(), a);
        }

        static void key(DrawContext g, int x, int y, int w, int h, String label, boolean down, float a) {
            Gfx.rrect(g, x, y, w, h, 3, down ? Gfx.argb(Gfx.grad(0.5f), a * 0.95f) : Gfx.argb(Gfx.BASE, a * 0.72f));
            float sc = h < 12 ? 0.8f : 1f;
            float tw = Gfx.width(label) * sc;
            Gfx.text(g, label, x + (w - tw) / 2f, y + (h - 8 * sc) / 2f, sc, a, down ? Gfx.BASE : Gfx.WHITE);
        }
    }
}
