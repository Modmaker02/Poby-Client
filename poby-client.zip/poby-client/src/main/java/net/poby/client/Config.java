package net.poby.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("poby-client.json");

    /** One entry of the Custom Text module (each is its own draggable HUD element). */
    public static class TextItem {
        public String id = Long.toString(System.nanoTime(), 36);
        public String text = "Custom Text";
        public boolean enabled = true, bg = true, underline = true;
        public int style = 0;      // 0 gradient, 1 white, 2 solid colour
        public int color = 0xFFFFFF;
        public int size = 1;       // 0 small .. 3 huge
    }

    public List<TextItem> texts = new ArrayList<>();
    public boolean textsInit = false;
    public boolean themeLoading = true, loadTips = true, themeOnServers = false;
    public int loadStyle = 0;      // 0 bar, 1 dots, 2 pulse
    public String loadTitle = "POBY CLIENT", loadSub = "Loading...";
    public int stackMin = 3;       // FPS Boost: hide extras when this many stack in one block

    public Map<String, Boolean> enabled = new HashMap<>();
    public Map<String, int[]> pos = new HashMap<>();
    public int colorA = 0x2FA8FF, colorB = 0xBFE6FF;
    public boolean gradientText = true, animations = true, boldFont = false, themeMenus = true;
    public int palette = 0;
    public float animSpeed = 1f;
    public String customText = "Poby Client";
    public int keyMenu = GLFW.GLFW_KEY_RIGHT_SHIFT;
    public int keyEditor = GLFW.GLFW_KEY_RIGHT_CONTROL;
    public int keySprint = GLFW.GLFW_KEY_G;
    public int keyBright = GLFW.GLFW_KEY_B;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (I.palette < 3) { // migrate old colours to the new Frost palette
            I.colorA = 0x2FA8FF;
            I.colorB = 0xBFE6FF;
            I.palette = 3;
        }
        if (I.texts == null) I.texts = new ArrayList<>();
        if (!I.textsInit) {
            if (I.texts.isEmpty()) {
                TextItem t = new TextItem();
                t.text = I.customText == null ? "Poby Client" : I.customText;
                I.texts.add(t);
            }
            I.textsInit = true;
        }
        if (I.loadTitle == null) I.loadTitle = "POBY CLIENT";
        if (I.loadSub == null) I.loadSub = "Loading...";
        if (I.enabled == null) I.enabled = new HashMap<>();
        if (I.pos == null) I.pos = new HashMap<>();
        if (I.customText == null) I.customText = "Poby Client";
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(I));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
