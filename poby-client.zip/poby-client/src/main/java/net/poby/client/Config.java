package net.poby.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("poby-client.json");

    public Map<String, Boolean> enabled = new HashMap<>();
    public Map<String, int[]> pos = new HashMap<>();
    public int colorA = 0x2D8CFF, colorB = 0xDDEBFF;
    public boolean gradientText = true, animations = true, boldFont = false, themeMenus = true;
    public int palette = 0;
    public float animSpeed = 1f;
    public String customText = "Poby Client";
    public int keyMenu = GLFW.GLFW_KEY_RIGHT_SHIFT;
    public int keyEditor = GLFW.GLFW_KEY_RIGHT_CONTROL;
    public int keySprint = GLFW.GLFW_KEY_G;
    public int keyBright = GLFW.GLFW_KEY_B;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (I.palette < 2) { // migrate old colours to the blue / white palette
            I.colorA = 0x2D8CFF;
            I.colorB = 0xDDEBFF;
            I.palette = 2;
        }
        if (I.enabled == null) I.enabled = new HashMap<>();
        if (I.pos == null) I.pos = new HashMap<>();
        if (I.customText == null) I.customText = "Poby Client";
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(I));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
