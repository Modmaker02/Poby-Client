package net.poby.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Frost list screen used by Singleplayer / Multiplayer. */
public abstract class PobyListScreen extends PobyScreen {
    static final int PW = 560, PH = 330, ROWS = 5, RH = 40, STRIDE = 46;
    protected final Screen parent;
    protected final String heading;
    protected int px, py, first, sel = -1;

    protected PobyListScreen(String heading, Screen parent) {
        super(Text.literal(heading));
        this.heading = heading;
        this.parent = parent;
    }

    protected abstract int count();

    protected abstract String countLabel();

    protected abstract String emptyText();

    protected abstract void drawRow(DrawContext g, int i, int x, int y, int w, int h, boolean hv);

    protected abstract void bottom(DrawContext g, int by);

    private void layout() {
        computeScale();
        px = (dw - PW) / 2;
        py = (dh - PH) / 2;
    }

    @Override
    protected void init() { layout(); }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    protected void onScroll(int d) {
        first = Math.max(0, Math.min(first + d, Math.max(0, count() - ROWS)));
    }

    @Override
    protected void paintBack(DrawContext g) {
        layout();
        if (client.world == null) Gfx.backdrop(g, dw, dh);
        else g.fill(0, 0, dw, dh, 0xB0050A14);
        Gfx.glass(g, px, py, PW, PH, 16, 0.80f, 0f);
        Gfx.hGradient(g, px + 18, py + 1, PW - 36, 1, 0.9f);
    }

    @Override
    protected void paintFront(DrawContext g) {
        if (iconButton(g, "<", px + 20, py + 14, 26)) act(this::close);
        Gfx.text(g, heading, px + 56, py + 19, 1.5f, 1f, -1);
        String cl = countLabel();
        Gfx.text(g, cl, px + PW - 20 - Gfx.width(cl), py + 22, 1f, 0.9f, Gfx.MUTED);

        int n = count();
        if (n == 0) {
            centered(g, emptyText(), px + PW / 2, py + 150, 1f, 1f, Gfx.MUTED);
        }
        first = Math.max(0, Math.min(first, Math.max(0, n - ROWS)));
        int rw = PW - 52;
        for (int k = 0; k < ROWS; k++) {
            int i = first + k;
            if (i >= n) break;
            int x = px + 20, y = py + 58 + k * STRIDE;
            boolean hv = hover(x, y, rw, RH), isSel = sel == i;
            if (isSel) {
                Gfx.rrectH(g, x - 1, y - 1, rw + 2, RH + 2, 11, 0.9f);
                Gfx.rrect(g, x, y, rw, RH, 10, Gfx.argb(Gfx.BASE, 0.95f));
            } else {
                Gfx.glass(g, x, y, rw, RH, 10, 0.35f, hv ? 0.05f : 0f);
            }
            if (pressed && hv) sel = i;
            drawRow(g, i, x, y, rw, RH, hv);
        }
        if (n > ROWS) {
            int th = ROWS * STRIDE - 6, ty = py + 58;
            Gfx.rrect(g, px + PW - 16, ty, 4, th, 2, Gfx.argb(0xFFFFFF, 0.12f));
            int thumb = Math.max(16, th * ROWS / n);
            int off = (th - thumb) * first / Math.max(1, n - ROWS);
            Gfx.rrectH(g, px + PW - 16, ty + off, 4, thumb, 2, 1f);
        }
        bottom(g, py + PH - 38);
    }

    protected void rowIcon(DrawContext g, String name, int x, int y) {
        Gfx.rrectH(g, x + 10, y + 7, 26, 26, 13, 1f);
        String ch = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        Gfx.text(g, ch, x + 23 - Gfx.width(ch) / 2f, y + 16, 1f, 1f, Gfx.BASE);
    }
}
